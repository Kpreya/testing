import React from 'react';
import { HashRouter, Routes, Route, useLocation } from 'react-router-dom';
import { Sidebar } from './components/Sidebar';
import { DashboardPage } from './pages/DashboardPage';
import { IssuesListPage } from './pages/IssuesListPage';
import { IssueDetailPage } from './pages/IssueDetailPage';
import { MonthlyReportPage } from './pages/MonthlyReportPage';
import { FigmaReviewPage } from './pages/FigmaReviewPage';
import { GitHubPRPage } from './pages/GitHubPRPage';
import { SettingsPage } from './pages/SettingsPage';
import { OnboardingPage } from './pages/OnboardingPage';
function AppLayout({ children }: {children: React.ReactNode;}) {
  const location = useLocation();
  const isOnboarding = location.pathname === '/onboarding';
  if (isOnboarding) {
    return <>{children}</>;
  }
  return (
    <div className="min-h-screen bg-[#0f0a1e]">
      <Sidebar />
      <main className="ml-[240px] p-8 transition-all">{children}</main>
    </div>);

}
function AppRoutes() {
  return (
    <AppLayout>
      <Routes>
        <Route path="/" element={<DashboardPage />} />
        <Route path="/issues" element={<IssuesListPage />} />
        <Route path="/issues/:id" element={<IssueDetailPage />} />
        <Route path="/report" element={<MonthlyReportPage />} />
        <Route path="/figma" element={<FigmaReviewPage />} />
        <Route path="/github" element={<GitHubPRPage />} />
        <Route path="/settings" element={<SettingsPage />} />
        <Route path="/onboarding" element={<OnboardingPage />} />
      </Routes>
    </AppLayout>);

}
export function App() {
  return (
    <HashRouter>
      <AppRoutes />
    </HashRouter>);

}