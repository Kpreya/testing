import React, { useState } from 'react';
import {
  GitPullRequestIcon,
  GitMergeIcon,
  GitBranchIcon,
  CheckCircleIcon,
  XCircleIcon,
  MessageSquareIcon,
  FileIcon,
  PlusIcon,
  MinusIcon,
  ChevronDownIcon,
  ChevronRightIcon,
  CopyIcon,
  ExternalLinkIcon,
  ClockIcon,
  AlertCircleIcon } from
'lucide-react';
// Mock PR data
const prData = {
  number: 1234,
  title: 'Fix TypeError in UserList component when API returns empty array',
  description: `## Summary
This PR fixes the critical TypeError that occurs when the API returns an empty array instead of null for the user list.

## Changes
- Added null check in UserList.tsx
- Updated API response handling in useUsers hook
- Added unit tests for edge cases

## Related Issues
- Fixes ISS-1234
- Related to ISS-1198

## Testing
- [x] Unit tests pass
- [x] Integration tests pass
- [x] Manual testing completed`,
  author: {
    name: 'Sarah Chen',
    initials: 'SC'
  },
  branch: 'fix/user-list-typeerror',
  baseBranch: 'main',
  status: 'open',
  createdAt: '2 hours ago',
  commits: 3,
  additions: 45,
  deletions: 12,
  changedFiles: 4,
  checks: [
  {
    name: 'Build',
    status: 'success'
  },
  {
    name: 'Unit Tests',
    status: 'success'
  },
  {
    name: 'Integration Tests',
    status: 'success'
  },
  {
    name: 'Lint',
    status: 'success'
  },
  {
    name: 'Type Check',
    status: 'pending'
  }],

  reviewers: [
  {
    name: 'Mike Ross',
    initials: 'MR',
    status: 'approved'
  },
  {
    name: 'Alex Kim',
    initials: 'AK',
    status: 'pending'
  }]

};
// Mock file changes
const fileChanges = [
{
  name: 'src/components/UserList.tsx',
  additions: 15,
  deletions: 3,
  diff: `@@ -42,7 +42,19 @@ export function UserList({ users }: UserListProps) {
-  return users.map((user) => (
+  if (!users || users.length === 0) {
+    return (
+      <div className="empty-state">
+        <p>No users found</p>
+      </div>
+    );
+  }
+
+  return users.map((user) => (`
},
{
  name: 'src/hooks/useUsers.ts',
  additions: 20,
  deletions: 5,
  diff: `@@ -15,8 +15,23 @@ export function useUsers() {
-  const { data } = await fetchUsers();
-  return data;
+  const { data } = await fetchUsers();
+  
+  // Handle empty or null response
+  if (!data) {
+    return [];
+  }
+  
+  return data;`
},
{
  name: 'src/components/__tests__/UserList.test.tsx',
  additions: 8,
  deletions: 2,
  diff: `@@ -25,6 +25,14 @@ describe('UserList', () => {
+  it('should render empty state when users is empty array', () => {
+    render(<UserList users={[]} />);
+    expect(screen.getByText('No users found')).toBeInTheDocument();
+  });
+
+  it('should render empty state when users is null', () => {
+    render(<UserList users={null} />);
+    expect(screen.getByText('No users found')).toBeInTheDocument();
+  });`
},
{
  name: 'src/types/user.ts',
  additions: 2,
  deletions: 2,
  diff: `@@ -5,5 +5,5 @@ export interface User {
 }

-export type UserListProps = {
-  users: User[];
+export type UserListProps = {
+  users: User[] | null;
 };`
}];

// Mock comments
const prComments = [
{
  id: 1,
  user: {
    name: 'Mike Ross',
    initials: 'MR'
  },
  message:
  'Great fix! The null check looks good. One small suggestion - should we also add a loading state?',
  timestamp: '1 hour ago',
  file: 'src/components/UserList.tsx',
  line: 45
},
{
  id: 2,
  user: {
    name: 'Sarah Chen',
    initials: 'SC'
  },
  message:
  "Good point! I'll add that in a follow-up PR to keep this one focused on the bug fix.",
  timestamp: '45 min ago',
  isReply: true
}];

function CheckIcon({ status }: {status: string;}) {
  switch (status) {
    case 'success':
      return <CheckCircleIcon className="w-4 h-4 text-[#22c55e]" />;
    case 'pending':
      return <ClockIcon className="w-4 h-4 text-[#f59e0b]" />;
    case 'failed':
      return <XCircleIcon className="w-4 h-4 text-[#e91e8c]" />;
    default:
      return null;
  }
}
export function GitHubPRPage() {
  const [expandedFiles, setExpandedFiles] = useState<string[]>([
  fileChanges[0].name]
  );
  const toggleFile = (fileName: string) => {
    setExpandedFiles((prev) =>
    prev.includes(fileName) ?
    prev.filter((f) => f !== fileName) :
    [...prev, fileName]
    );
  };
  return (
    <div className="min-h-screen">
      {/* Header */}
      <div className="sf-card p-6 mb-6">
        <div className="flex items-start justify-between mb-4">
          <div className="flex items-start gap-4">
            <div className="w-12 h-12 rounded-xl bg-[#22c55e]/20 flex items-center justify-center">
              <GitPullRequestIcon className="w-6 h-6 text-[#22c55e]" />
            </div>
            <div>
              <div className="flex items-center gap-3 mb-2">
                <span className="px-2 py-1 rounded-full text-xs font-medium bg-[#22c55e]/20 text-[#22c55e]">
                  Open
                </span>
                <span className="text-[#6b5f8a] font-mono">
                  #{prData.number}
                </span>
              </div>
              <h1 className="text-2xl font-bold text-[#e2dff0] mb-2">
                {prData.title}
              </h1>
              <div className="flex items-center gap-4 text-sm text-[#9b8fc2]">
                <div className="flex items-center gap-2">
                  <div className="w-6 h-6 rounded-full bg-gradient-to-br from-[#e91e8c] to-[#7c3aed] flex items-center justify-center text-white text-xs font-medium">
                    {prData.author.initials}
                  </div>
                  <span>{prData.author.name}</span>
                </div>
                <span>opened {prData.createdAt}</span>
                <span className="flex items-center gap-1">
                  <GitBranchIcon className="w-4 h-4" />
                  {prData.branch}
                </span>
              </div>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button className="sf-btn-secondary flex items-center gap-2">
              <MessageSquareIcon className="w-4 h-4" />
              Comment
            </button>
            <button className="sf-btn-primary flex items-center gap-2">
              <GitMergeIcon className="w-4 h-4" />
              Merge PR
            </button>
          </div>
        </div>

        {/* Branch Info */}
        <div className="flex items-center gap-2 p-3 bg-[#0f0a1e] rounded-lg text-sm">
          <GitBranchIcon className="w-4 h-4 text-[#7c3aed]" />
          <span className="font-mono text-[#9b8fc2]">{prData.branch}</span>
          <span className="text-[#6b5f8a]">→</span>
          <span className="font-mono text-[#9b8fc2]">{prData.baseBranch}</span>
          <button className="ml-auto sf-btn-ghost p-1">
            <CopyIcon className="w-4 h-4" />
          </button>
        </div>
      </div>

      <div className="grid grid-cols-3 gap-6">
        {/* Main Content */}
        <div className="col-span-2 space-y-6">
          {/* Description */}
          <div className="sf-card p-6">
            <h2 className="text-lg font-semibold text-[#e2dff0] mb-4">
              Description
            </h2>
            <div className="prose prose-invert prose-sm max-w-none">
              <div className="text-[#9b8fc2] whitespace-pre-wrap">
                {prData.description}
              </div>
            </div>
          </div>

          {/* File Changes */}
          <div className="sf-card overflow-hidden">
            <div className="p-4 border-b border-[rgba(124,58,237,0.2)] flex items-center justify-between">
              <h2 className="text-lg font-semibold text-[#e2dff0]">
                Files Changed
              </h2>
              <div className="flex items-center gap-4 text-sm">
                <span className="text-[#22c55e]">+{prData.additions}</span>
                <span className="text-[#e91e8c]">-{prData.deletions}</span>
                <span className="text-[#9b8fc2]">
                  {prData.changedFiles} files
                </span>
              </div>
            </div>

            <div className="divide-y divide-[rgba(124,58,237,0.1)]">
              {fileChanges.map((file) =>
              <div key={file.name}>
                  <button
                  onClick={() => toggleFile(file.name)}
                  className="w-full p-4 flex items-center justify-between hover:bg-[#7c3aed]/5 transition-colors">

                    <div className="flex items-center gap-3">
                      {expandedFiles.includes(file.name) ?
                    <ChevronDownIcon className="w-4 h-4 text-[#6b5f8a]" /> :

                    <ChevronRightIcon className="w-4 h-4 text-[#6b5f8a]" />
                    }
                      <FileIcon className="w-4 h-4 text-[#7c3aed]" />
                      <span className="font-mono text-sm text-[#e2dff0]">
                        {file.name}
                      </span>
                    </div>
                    <div className="flex items-center gap-3 text-sm">
                      <span className="text-[#22c55e]">+{file.additions}</span>
                      <span className="text-[#e91e8c]">-{file.deletions}</span>
                    </div>
                  </button>

                  {expandedFiles.includes(file.name) &&
                <div className="bg-[#0f0a1e] p-4 overflow-x-auto">
                      <pre className="text-sm font-mono leading-relaxed">
                        {file.diff.split('\n').map((line, i) =>
                    <div
                      key={i}
                      className={`px-2 ${line.startsWith('+') && !line.startsWith('@@') ? 'bg-[#22c55e]/10 text-[#22c55e]' : line.startsWith('-') && !line.startsWith('@@') ? 'bg-[#e91e8c]/10 text-[#e91e8c]' : line.startsWith('@@') ? 'text-[#7c3aed]' : 'text-[#9b8fc2]'}`}>

                            {line}
                          </div>
                    )}
                      </pre>
                    </div>
                }
                </div>
              )}
            </div>
          </div>

          {/* Comments */}
          <div className="sf-card p-6">
            <h2 className="text-lg font-semibold text-[#e2dff0] mb-4">
              Conversation
            </h2>
            <div className="space-y-4">
              {prComments.map((comment) =>
              <div
                key={comment.id}
                className={`p-4 rounded-lg bg-[#0f0a1e] ${comment.isReply ? 'ml-8' : ''}`}>

                  <div className="flex items-start gap-3">
                    <div className="w-8 h-8 rounded-full bg-gradient-to-br from-[#e91e8c] to-[#7c3aed] flex items-center justify-center text-white text-xs font-medium">
                      {comment.user.initials}
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-2">
                        <span className="font-medium text-[#e2dff0]">
                          {comment.user.name}
                        </span>
                        <span className="text-xs text-[#6b5f8a]">
                          {comment.timestamp}
                        </span>
                        {comment.file &&
                      <span className="text-xs text-[#7c3aed] font-mono">
                            {comment.file}:{comment.line}
                          </span>
                      }
                      </div>
                      <p className="text-[#9b8fc2]">{comment.message}</p>
                    </div>
                  </div>
                </div>
              )}
            </div>

            <div className="mt-4 pt-4 border-t border-[rgba(124,58,237,0.2)]">
              <textarea
                placeholder="Leave a comment..."
                className="sf-input min-h-[100px] resize-none mb-3" />

              <div className="flex justify-end">
                <button className="sf-btn-primary">Comment</button>
              </div>
            </div>
          </div>
        </div>

        {/* Sidebar */}
        <div className="space-y-6">
          {/* Checks */}
          <div className="sf-card p-4">
            <h3 className="text-sm font-semibold text-[#9b8fc2] uppercase tracking-wider mb-3">
              Checks
            </h3>
            <div className="space-y-2">
              {prData.checks.map((check) =>
              <div
                key={check.name}
                className="flex items-center justify-between p-2 rounded-lg hover:bg-[#7c3aed]/5">

                  <div className="flex items-center gap-2">
                    <CheckIcon status={check.status} />
                    <span className="text-sm text-[#e2dff0]">{check.name}</span>
                  </div>
                  <span
                  className={`text-xs ${check.status === 'success' ? 'text-[#22c55e]' : check.status === 'pending' ? 'text-[#f59e0b]' : 'text-[#e91e8c]'}`}>

                    {check.status}
                  </span>
                </div>
              )}
            </div>
          </div>

          {/* Reviewers */}
          <div className="sf-card p-4">
            <h3 className="text-sm font-semibold text-[#9b8fc2] uppercase tracking-wider mb-3">
              Reviewers
            </h3>
            <div className="space-y-3">
              {prData.reviewers.map((reviewer) =>
              <div
                key={reviewer.name}
                className="flex items-center justify-between">

                  <div className="flex items-center gap-2">
                    <div className="w-7 h-7 rounded-full bg-gradient-to-br from-[#e91e8c] to-[#7c3aed] flex items-center justify-center text-white text-xs font-medium">
                      {reviewer.initials}
                    </div>
                    <span className="text-sm text-[#e2dff0]">
                      {reviewer.name}
                    </span>
                  </div>
                  {reviewer.status === 'approved' ?
                <CheckCircleIcon className="w-5 h-5 text-[#22c55e]" /> :

                <ClockIcon className="w-5 h-5 text-[#f59e0b]" />
                }
                </div>
              )}
            </div>
          </div>

          {/* Stats */}
          <div className="sf-card p-4">
            <h3 className="text-sm font-semibold text-[#9b8fc2] uppercase tracking-wider mb-3">
              Stats
            </h3>
            <div className="space-y-3 text-sm">
              <div className="flex justify-between">
                <span className="text-[#6b5f8a]">Commits</span>
                <span className="text-[#e2dff0]">{prData.commits}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-[#6b5f8a]">Files Changed</span>
                <span className="text-[#e2dff0]">{prData.changedFiles}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-[#6b5f8a]">Additions</span>
                <span className="text-[#22c55e]">+{prData.additions}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-[#6b5f8a]">Deletions</span>
                <span className="text-[#e91e8c]">-{prData.deletions}</span>
              </div>
            </div>
          </div>

          {/* Related Issues */}
          <div className="sf-card p-4">
            <h3 className="text-sm font-semibold text-[#9b8fc2] uppercase tracking-wider mb-3">
              Related Issues
            </h3>
            <div className="space-y-2">
              <a
                href="#"
                className="flex items-center gap-2 p-2 rounded-lg hover:bg-[#7c3aed]/10 transition-colors">

                <AlertCircleIcon className="w-4 h-4 text-[#e91e8c]" />
                <span className="text-sm text-[#e2dff0]">ISS-1234</span>
                <span className="text-xs text-[#6b5f8a]">Fixes</span>
              </a>
              <a
                href="#"
                className="flex items-center gap-2 p-2 rounded-lg hover:bg-[#7c3aed]/10 transition-colors">

                <AlertCircleIcon className="w-4 h-4 text-[#f59e0b]" />
                <span className="text-sm text-[#e2dff0]">ISS-1198</span>
                <span className="text-xs text-[#6b5f8a]">Related</span>
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>);

}