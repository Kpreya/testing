import React, { Children, Component } from 'react';
import { useParams, Link } from 'react-router-dom';
import {
  ChevronRightIcon,
  AlertCircleIcon,
  ClockIcon,
  UsersIcon,
  ActivityIcon,
  GitBranchIcon,
  MessageSquareIcon,
  TagIcon,
  LinkIcon,
  MoreHorizontalIcon,
  PlayIcon,
  CheckCircleIcon,
  XCircleIcon,
  RefreshCwIcon,
  ExternalLinkIcon } from
'lucide-react';
import {
  AreaChart,
  Area,
  ResponsiveContainer,
  XAxis,
  YAxis,
  Tooltip } from
'recharts';
// Event frequency data
const eventFrequencyData = [
{
  time: '00:00',
  events: 45
},
{
  time: '04:00',
  events: 32
},
{
  time: '08:00',
  events: 89
},
{
  time: '12:00',
  events: 234
},
{
  time: '16:00',
  events: 456
},
{
  time: '20:00',
  events: 321
},
{
  time: '24:00',
  events: 178
}];

// Timeline events
const timelineEvents = [
{
  id: 1,
  type: 'created',
  user: {
    name: 'System',
    initials: 'SY'
  },
  message: 'Issue automatically created from error tracking',
  timestamp: '2 days ago',
  details: 'First occurrence detected in production environment'
},
{
  id: 2,
  type: 'assigned',
  user: {
    name: 'Mike Ross',
    initials: 'MR'
  },
  message: 'Assigned to Sarah Chen',
  timestamp: '2 days ago'
},
{
  id: 3,
  type: 'comment',
  user: {
    name: 'Sarah Chen',
    initials: 'SC'
  },
  message:
  'Investigating the root cause. Looks like it might be related to the recent API changes.',
  timestamp: '1 day ago'
},
{
  id: 4,
  type: 'status',
  user: {
    name: 'Sarah Chen',
    initials: 'SC'
  },
  message: 'Changed status to Investigating',
  timestamp: '1 day ago'
},
{
  id: 5,
  type: 'linked',
  user: {
    name: 'Sarah Chen',
    initials: 'SC'
  },
  message: 'Linked to GitHub PR #1234',
  timestamp: '12 hours ago'
},
{
  id: 6,
  type: 'comment',
  user: {
    name: 'Alex Kim',
    initials: 'AK'
  },
  message:
  'I can reproduce this on staging. The issue occurs when the API returns an empty array instead of null.',
  timestamp: '6 hours ago'
}];

// Stack trace
const stackTrace = `TypeError: Cannot read property 'map' of undefined
    at UserList.render (UserList.tsx:45:23)
    at processChild (react-dom.development.js:3456:14)
    at processChildren (react-dom.development.js:3512:5)
    at reconcileChildren (react-dom.development.js:4567:3)
    at updateFunctionComponent (react-dom.development.js:5678:7)
    at beginWork (react-dom.development.js:6789:16)
    at performUnitOfWork (react-dom.development.js:7890:12)
    at workLoopSync (react-dom.development.js:7901:5)`;
// Tags
const tags = ['frontend', 'react', 'production', 'user-facing'];
function TimelineIcon({ type }: {type: string;}) {
  switch (type) {
    case 'created':
      return <AlertCircleIcon className="w-4 h-4 text-[#e91e8c]" />;
    case 'assigned':
      return <UsersIcon className="w-4 h-4 text-[#7c3aed]" />;
    case 'comment':
      return <MessageSquareIcon className="w-4 h-4 text-[#9b8fc2]" />;
    case 'status':
      return <RefreshCwIcon className="w-4 h-4 text-[#f59e0b]" />;
    case 'linked':
      return <LinkIcon className="w-4 h-4 text-[#22c55e]" />;
    default:
      return <ActivityIcon className="w-4 h-4 text-[#9b8fc2]" />;
  }
}
export function IssueDetailPage() {
  const { id } = useParams();
  return (
    <div className="min-h-screen">
      {/* Breadcrumb */}
      <nav className="flex items-center gap-2 text-sm mb-6">
        <Link
          to="/issues"
          className="text-[#9b8fc2] hover:text-[#e2dff0] transition-colors">

          Issues
        </Link>
        <ChevronRightIcon className="w-4 h-4 text-[#6b5f8a]" />
        <span className="text-[#e2dff0] font-medium">{id || 'ISS-1234'}</span>
      </nav>

      {/* Header */}
      <div className="sf-card p-6 mb-6">
        <div className="flex items-start justify-between mb-4">
          <div className="flex items-start gap-4">
            <div className="w-12 h-12 rounded-xl bg-[#e91e8c]/20 flex items-center justify-center">
              <AlertCircleIcon className="w-6 h-6 text-[#e91e8c]" />
            </div>
            <div>
              <div className="flex items-center gap-3 mb-2">
                <span className="sf-badge sf-badge-critical">Critical</span>
                <span className="text-xs text-[#6b5f8a] font-mono">
                  {id || 'ISS-1234'}
                </span>
              </div>
              <h1 className="text-2xl font-bold text-[#e2dff0] mb-2">
                TypeError: Cannot read property "map" of undefined
              </h1>
              <div className="flex items-center gap-4 text-sm text-[#9b8fc2]">
                <span className="flex items-center gap-1">
                  <ClockIcon className="w-4 h-4" />
                  First seen 2 days ago
                </span>
                <span className="flex items-center gap-1">
                  <ActivityIcon className="w-4 h-4" />
                  Last seen 2 min ago
                </span>
              </div>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button className="sf-btn-secondary flex items-center gap-2">
              <CheckCircleIcon className="w-4 h-4" />
              Resolve
            </button>
            <button className="sf-btn-secondary flex items-center gap-2">
              <XCircleIcon className="w-4 h-4" />
              Ignore
            </button>
            <button className="sf-btn-primary flex items-center gap-2">
              <GitBranchIcon className="w-4 h-4" />
              Create PR
            </button>
            <button className="sf-btn-ghost p-2">
              <MoreHorizontalIcon className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Stats Row */}
        <div className="grid grid-cols-4 gap-4 pt-4 border-t border-[rgba(124,58,237,0.2)]">
          <div>
            <p className="text-sm text-[#9b8fc2] mb-1">Total Events</p>
            <p className="text-2xl font-bold text-[#e2dff0]">2,847</p>
          </div>
          <div>
            <p className="text-sm text-[#9b8fc2] mb-1">Affected Users</p>
            <p className="text-2xl font-bold text-[#e2dff0]">1,234</p>
          </div>
          <div>
            <p className="text-sm text-[#9b8fc2] mb-1">Status</p>
            <div className="flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-[#f59e0b]" />
              <span className="text-lg font-semibold text-[#f59e0b]">
                Investigating
              </span>
            </div>
          </div>
          <div>
            <p className="text-sm text-[#9b8fc2] mb-1">Assignee</p>
            <div className="flex items-center gap-2">
              <div className="w-7 h-7 rounded-full bg-gradient-to-br from-[#e91e8c] to-[#7c3aed] flex items-center justify-center text-white text-xs font-medium">
                SC
              </div>
              <span className="text-[#e2dff0] font-medium">Sarah Chen</span>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content Grid */}
      <div className="grid grid-cols-3 gap-6">
        {/* Left Column - Main Content */}
        <div className="col-span-2 space-y-6">
          {/* Event Frequency Chart */}
          <div className="sf-card p-6">
            <h2 className="text-lg font-semibold text-[#e2dff0] mb-4">
              Event Frequency (24h)
            </h2>
            <div className="h-48">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={eventFrequencyData}>
                  <defs>
                    <linearGradient
                      id="eventGradient"
                      x1="0"
                      y1="0"
                      x2="0"
                      y2="1">

                      <stop offset="0%" stopColor="#e91e8c" stopOpacity={0.4} />
                      <stop
                        offset="100%"
                        stopColor="#7c3aed"
                        stopOpacity={0.1} />

                    </linearGradient>
                  </defs>
                  <XAxis
                    dataKey="time"
                    axisLine={false}
                    tickLine={false}
                    tick={{
                      fill: '#6b5f8a',
                      fontSize: 12
                    }} />

                  <YAxis
                    axisLine={false}
                    tickLine={false}
                    tick={{
                      fill: '#6b5f8a',
                      fontSize: 12
                    }} />

                  <Tooltip
                    contentStyle={{
                      background: '#1a1333',
                      border: '1px solid rgba(124, 58, 237, 0.3)',
                      borderRadius: '8px',
                      color: '#e2dff0'
                    }} />

                  <Area
                    type="monotone"
                    dataKey="events"
                    stroke="#e91e8c"
                    strokeWidth={2}
                    fill="url(#eventGradient)" />

                </AreaChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Stack Trace */}
          <div className="sf-card p-6">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-lg font-semibold text-[#e2dff0]">
                Stack Trace
              </h2>
              <button className="sf-btn-ghost text-sm flex items-center gap-2">
                <ExternalLinkIcon className="w-4 h-4" />
                View in Source
              </button>
            </div>
            <pre className="bg-[#0f0a1e] rounded-lg p-4 overflow-x-auto text-sm font-mono text-[#9b8fc2] leading-relaxed">
              {stackTrace}
            </pre>
          </div>

          {/* Activity Timeline */}
          <div className="sf-card p-6">
            <h2 className="text-lg font-semibold text-[#e2dff0] mb-6">
              Activity
            </h2>
            <div className="space-y-6">
              {timelineEvents.map((event, index) =>
              <div key={event.id} className="flex gap-4">
                  <div className="flex flex-col items-center">
                    <div className="w-8 h-8 rounded-full bg-[#2d1f5e] flex items-center justify-center">
                      <TimelineIcon type={event.type} />
                    </div>
                    {index < timelineEvents.length - 1 &&
                  <div className="w-px h-full bg-[rgba(124,58,237,0.2)] mt-2" />
                  }
                  </div>
                  <div className="flex-1 pb-6">
                    <div className="flex items-center gap-2 mb-1">
                      <div className="w-6 h-6 rounded-full bg-gradient-to-br from-[#e91e8c] to-[#7c3aed] flex items-center justify-center text-white text-[10px] font-medium">
                        {event.user.initials}
                      </div>
                      <span className="font-medium text-[#e2dff0]">
                        {event.user.name}
                      </span>
                      <span className="text-[#6b5f8a] text-sm">
                        {event.timestamp}
                      </span>
                    </div>
                    <p className="text-[#9b8fc2]">{event.message}</p>
                    {event.details &&
                  <p className="text-sm text-[#6b5f8a] mt-1">
                        {event.details}
                      </p>
                  }
                  </div>
                </div>
              )}
            </div>

            {/* Add Comment */}
            <div className="mt-6 pt-6 border-t border-[rgba(124,58,237,0.2)]">
              <textarea
                placeholder="Add a comment..."
                className="sf-input min-h-[100px] resize-none mb-3" />

              <div className="flex justify-end">
                <button className="sf-btn-primary">Post Comment</button>
              </div>
            </div>
          </div>
        </div>

        {/* Right Column - Sidebar */}
        <div className="space-y-6">
          {/* Quick Actions */}
          <div className="sf-card p-4">
            <h3 className="text-sm font-semibold text-[#9b8fc2] uppercase tracking-wider mb-3">
              Quick Actions
            </h3>
            <div className="space-y-2">
              <button className="w-full sf-btn-secondary justify-start flex items-center gap-2 text-sm">
                <PlayIcon className="w-4 h-4" />
                Replay Session
              </button>
              <button className="w-full sf-btn-secondary justify-start flex items-center gap-2 text-sm">
                <GitBranchIcon className="w-4 h-4" />
                View Related PRs
              </button>
              <button className="w-full sf-btn-secondary justify-start flex items-center gap-2 text-sm">
                <LinkIcon className="w-4 h-4" />
                Copy Issue Link
              </button>
            </div>
          </div>

          {/* Tags */}
          <div className="sf-card p-4">
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-sm font-semibold text-[#9b8fc2] uppercase tracking-wider">
                Tags
              </h3>
              <button className="text-[#7c3aed] text-sm hover:underline">
                Edit
              </button>
            </div>
            <div className="flex flex-wrap gap-2">
              {tags.map((tag) =>
              <span key={tag} className="sf-badge sf-badge-info">
                  <TagIcon className="w-3 h-3 mr-1" />
                  {tag}
                </span>
              )}
            </div>
          </div>

          {/* Environment */}
          <div className="sf-card p-4">
            <h3 className="text-sm font-semibold text-[#9b8fc2] uppercase tracking-wider mb-3">
              Environment
            </h3>
            <div className="space-y-3 text-sm">
              <div className="flex justify-between">
                <span className="text-[#6b5f8a]">Browser</span>
                <span className="text-[#e2dff0]">Chrome 120.0</span>
              </div>
              <div className="flex justify-between">
                <span className="text-[#6b5f8a]">OS</span>
                <span className="text-[#e2dff0]">macOS 14.2</span>
              </div>
              <div className="flex justify-between">
                <span className="text-[#6b5f8a]">Device</span>
                <span className="text-[#e2dff0]">Desktop</span>
              </div>
              <div className="flex justify-between">
                <span className="text-[#6b5f8a]">Release</span>
                <span className="text-[#e2dff0] font-mono">v2.4.1</span>
              </div>
            </div>
          </div>

          {/* Linked Issues */}
          <div className="sf-card p-4">
            <h3 className="text-sm font-semibold text-[#9b8fc2] uppercase tracking-wider mb-3">
              Linked
            </h3>
            <div className="space-y-2">
              <a
                href="#"
                className="flex items-center gap-2 p-2 rounded-lg hover:bg-[#7c3aed]/10 transition-colors">

                <GitBranchIcon className="w-4 h-4 text-[#22c55e]" />
                <span className="text-sm text-[#e2dff0]">PR #1234</span>
                <span className="text-xs text-[#6b5f8a]">Open</span>
              </a>
              <a
                href="#"
                className="flex items-center gap-2 p-2 rounded-lg hover:bg-[#7c3aed]/10 transition-colors">

                <AlertCircleIcon className="w-4 h-4 text-[#f59e0b]" />
                <span className="text-sm text-[#e2dff0]">ISS-1198</span>
                <span className="text-xs text-[#6b5f8a]">Related</span>
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>);

}