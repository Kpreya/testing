import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  ZapIcon,
  ArrowRightIcon,
  ArrowLeftIcon,
  CheckIcon,
  CodeIcon,
  BellIcon,
  UsersIcon,
  RocketIcon,
  GithubIcon,
  GitlabIcon,
  ChromeIcon } from
'lucide-react';
type Step = 1 | 2 | 3 | 4;
const steps = [
{
  number: 1,
  title: 'Connect Repository',
  description: 'Link your code repository'
},
{
  number: 2,
  title: 'Install SDK',
  description: 'Add SynapseFlow to your app'
},
{
  number: 3,
  title: 'Configure Alerts',
  description: 'Set up notifications'
},
{
  number: 4,
  title: 'Invite Team',
  description: 'Add your teammates'
}];

export function OnboardingPage() {
  const [currentStep, setCurrentStep] = useState<Step>(1);
  const [selectedRepo, setSelectedRepo] = useState<string | null>(null);
  const [selectedPlatform, setSelectedPlatform] = useState<string | null>(null);
  const navigate = useNavigate();
  const nextStep = () => {
    if (currentStep < 4) {
      setCurrentStep(currentStep + 1 as Step);
    } else {
      navigate('/');
    }
  };
  const prevStep = () => {
    if (currentStep > 1) {
      setCurrentStep(currentStep - 1 as Step);
    }
  };
  return (
    <div className="min-h-screen bg-[#0f0a1e] flex">
      {/* Left Panel - Progress */}
      <div className="w-80 bg-[#150e2b] border-r border-[rgba(124,58,237,0.2)] p-8 flex flex-col">
        {/* Logo */}
        <div className="flex items-center gap-3 mb-12">
          <div className="w-10 h-10 rounded-xl sf-gradient-bg flex items-center justify-center sf-glow-magenta">
            <ZapIcon className="w-6 h-6 text-white" />
          </div>
          <span className="text-xl font-bold sf-gradient-text">
            SynapseFlow
          </span>
        </div>

        {/* Steps */}
        <div className="space-y-6 flex-1">
          {steps.map((step, index) =>
          <div key={step.number} className="flex gap-4">
              <div className="flex flex-col items-center">
                <div
                className={`w-10 h-10 rounded-full flex items-center justify-center font-semibold transition-all ${currentStep > step.number ? 'bg-[#22c55e] text-white' : currentStep === step.number ? 'sf-gradient-bg text-white sf-glow-magenta' : 'bg-[#2d1f5e] text-[#6b5f8a]'}`}>

                  {currentStep > step.number ?
                <CheckIcon className="w-5 h-5" /> :

                step.number
                }
                </div>
                {index < steps.length - 1 &&
              <div
                className={`w-0.5 h-12 mt-2 ${currentStep > step.number ? 'bg-[#22c55e]' : 'bg-[#2d1f5e]'}`} />

              }
              </div>
              <div>
                <p
                className={`font-medium ${currentStep >= step.number ? 'text-[#e2dff0]' : 'text-[#6b5f8a]'}`}>

                  {step.title}
                </p>
                <p className="text-sm text-[#6b5f8a]">{step.description}</p>
              </div>
            </div>
          )}
        </div>

        {/* Help */}
        <div className="pt-6 border-t border-[rgba(124,58,237,0.2)]">
          <p className="text-sm text-[#6b5f8a]">Need help?</p>
          <a href="#" className="text-sm text-[#7c3aed] hover:underline">
            View documentation →
          </a>
        </div>
      </div>

      {/* Right Panel - Content */}
      <div className="flex-1 flex flex-col">
        <div className="flex-1 flex items-center justify-center p-12">
          <div className="w-full max-w-xl">
            {/* Step 1: Connect Repository */}
            {currentStep === 1 &&
            <div>
                <h1 className="text-3xl font-bold text-[#e2dff0] mb-2">
                  Connect Your Repository
                </h1>
                <p className="text-[#9b8fc2] mb-8">
                  Choose your code hosting platform to get started
                </p>

                <div className="space-y-4">
                  {[
                {
                  id: 'github',
                  name: 'GitHub',
                  icon: <GithubIcon className="w-6 h-6" />,
                  desc: 'Connect your GitHub repositories'
                },
                {
                  id: 'gitlab',
                  name: 'GitLab',
                  icon: <GitlabIcon className="w-6 h-6" />,
                  desc: 'Connect your GitLab projects'
                },
                {
                  id: 'bitbucket',
                  name: 'Bitbucket',
                  icon: <CodeIcon className="w-6 h-6" />,
                  desc: 'Connect your Bitbucket repos'
                }].
                map((platform) =>
                <button
                  key={platform.id}
                  onClick={() => setSelectedPlatform(platform.id)}
                  className={`w-full p-4 rounded-xl flex items-center gap-4 transition-all ${selectedPlatform === platform.id ? 'bg-[#7c3aed]/20 border-2 border-[#7c3aed]' : 'bg-[#1a1333] border-2 border-transparent hover:border-[rgba(124,58,237,0.3)]'}`}>

                      <div className="w-12 h-12 rounded-lg bg-[#2d1f5e] flex items-center justify-center text-[#9b8fc2]">
                        {platform.icon}
                      </div>
                      <div className="text-left">
                        <p className="font-semibold text-[#e2dff0]">
                          {platform.name}
                        </p>
                        <p className="text-sm text-[#6b5f8a]">
                          {platform.desc}
                        </p>
                      </div>
                      {selectedPlatform === platform.id &&
                  <CheckIcon className="w-5 h-5 text-[#7c3aed] ml-auto" />
                  }
                    </button>
                )}
                </div>

                {selectedPlatform &&
              <div className="mt-6 p-4 bg-[#1a1333] rounded-xl">
                    <p className="text-sm text-[#9b8fc2] mb-3">
                      Select a repository:
                    </p>
                    <div className="space-y-2">
                      {[
                  'synapseflow/frontend',
                  'synapseflow/backend',
                  'synapseflow/mobile'].
                  map((repo) =>
                  <button
                    key={repo}
                    onClick={() => setSelectedRepo(repo)}
                    className={`w-full p-3 rounded-lg text-left flex items-center justify-between ${selectedRepo === repo ? 'bg-[#7c3aed]/20 text-[#e2dff0]' : 'bg-[#0f0a1e] text-[#9b8fc2] hover:bg-[#2d1f5e]/30'}`}>

                          <span className="font-mono text-sm">{repo}</span>
                          {selectedRepo === repo &&
                    <CheckIcon className="w-4 h-4 text-[#7c3aed]" />
                    }
                        </button>
                  )}
                    </div>
                  </div>
              }
              </div>
            }

            {/* Step 2: Install SDK */}
            {currentStep === 2 &&
            <div>
                <h1 className="text-3xl font-bold text-[#e2dff0] mb-2">
                  Install the SDK
                </h1>
                <p className="text-[#9b8fc2] mb-8">
                  Add SynapseFlow to your application in minutes
                </p>

                <div className="space-y-6">
                  <div>
                    <p className="text-sm font-medium text-[#9b8fc2] mb-2">
                      1. Install the package
                    </p>
                    <div className="bg-[#0f0a1e] rounded-lg p-4 font-mono text-sm">
                      <span className="text-[#6b5f8a]">$</span>{' '}
                      <span className="text-[#e2dff0]">
                        npm install @synapseflow/sdk
                      </span>
                    </div>
                  </div>

                  <div>
                    <p className="text-sm font-medium text-[#9b8fc2] mb-2">
                      2. Initialize in your app
                    </p>
                    <div className="bg-[#0f0a1e] rounded-lg p-4 font-mono text-sm overflow-x-auto">
                      <pre className="text-[#9b8fc2]">
                        {`import { SynapseFlow } from '@synapseflow/sdk';

SynapseFlow.init({
  dsn: 'https://abc123@synapseflow.io/1',
  environment: 'production',
  release: '1.0.0',
});`}
                      </pre>
                    </div>
                  </div>

                  <div className="p-4 bg-[#22c55e]/10 border border-[#22c55e]/30 rounded-lg">
                    <div className="flex items-center gap-2 text-[#22c55e] mb-2">
                      <CheckIcon className="w-5 h-5" />
                      <span className="font-medium">SDK Detected!</span>
                    </div>
                    <p className="text-sm text-[#9b8fc2]">
                      We detected the SDK in your application. You're all set!
                    </p>
                  </div>
                </div>
              </div>
            }

            {/* Step 3: Configure Alerts */}
            {currentStep === 3 &&
            <div>
                <h1 className="text-3xl font-bold text-[#e2dff0] mb-2">
                  Configure Alerts
                </h1>
                <p className="text-[#9b8fc2] mb-8">
                  Set up how you want to be notified about issues
                </p>

                <div className="space-y-4">
                  <div className="p-4 bg-[#1a1333] rounded-xl">
                    <div className="flex items-center justify-between mb-4">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-lg bg-[#2d1f5e] flex items-center justify-center">
                          <BellIcon className="w-5 h-5 text-[#7c3aed]" />
                        </div>
                        <div>
                          <p className="font-medium text-[#e2dff0]">
                            Email Notifications
                          </p>
                          <p className="text-sm text-[#6b5f8a]">
                            Get alerts via email
                          </p>
                        </div>
                      </div>
                      <button className="w-12 h-6 rounded-full bg-[#7c3aed]">
                        <div className="w-5 h-5 rounded-full bg-white translate-x-6" />
                      </button>
                    </div>
                    <input
                    type="email"
                    placeholder="your@email.com"
                    className="sf-input"
                    defaultValue="john@synapseflow.io" />

                  </div>

                  <div className="p-4 bg-[#1a1333] rounded-xl">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-lg bg-[#2d1f5e] flex items-center justify-center text-2xl">
                          💬
                        </div>
                        <div>
                          <p className="font-medium text-[#e2dff0]">
                            Slack Integration
                          </p>
                          <p className="text-sm text-[#6b5f8a]">
                            Send alerts to Slack
                          </p>
                        </div>
                      </div>
                      <button className="sf-btn-secondary text-sm">
                        Connect
                      </button>
                    </div>
                  </div>

                  <div className="p-4 bg-[#1a1333] rounded-xl">
                    <p className="font-medium text-[#e2dff0] mb-3">
                      Alert Threshold
                    </p>
                    <div className="space-y-2">
                      {[
                    'All issues',
                    'High priority and above',
                    'Critical only'].
                    map((option, i) =>
                    <label
                      key={option}
                      className="flex items-center gap-3 cursor-pointer">

                          <input
                        type="radio"
                        name="threshold"
                        defaultChecked={i === 1}
                        className="w-4 h-4 accent-[#7c3aed]" />

                          <span className="text-[#9b8fc2]">{option}</span>
                        </label>
                    )}
                    </div>
                  </div>
                </div>
              </div>
            }

            {/* Step 4: Invite Team */}
            {currentStep === 4 &&
            <div>
                <h1 className="text-3xl font-bold text-[#e2dff0] mb-2">
                  Invite Your Team
                </h1>
                <p className="text-[#9b8fc2] mb-8">
                  Collaborate with your teammates on issue resolution
                </p>

                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-[#9b8fc2] mb-2">
                      Email addresses (comma separated)
                    </label>
                    <textarea
                    className="sf-input min-h-[100px] resize-none"
                    placeholder="sarah@company.com, mike@company.com" />

                  </div>

                  <div className="p-4 bg-[#1a1333] rounded-xl">
                    <p className="font-medium text-[#e2dff0] mb-3">
                      Default Role
                    </p>
                    <select className="sf-input">
                      <option>Developer</option>
                      <option>Viewer</option>
                      <option>Admin</option>
                    </select>
                  </div>

                  <div className="flex items-center gap-2 text-sm text-[#6b5f8a]">
                    <UsersIcon className="w-4 h-4" />
                    <span>
                      You can always invite more team members later from
                      Settings
                    </span>
                  </div>
                </div>
              </div>
            }
          </div>
        </div>

        {/* Footer Navigation */}
        <div className="p-6 border-t border-[rgba(124,58,237,0.2)] flex items-center justify-between">
          <button
            onClick={prevStep}
            disabled={currentStep === 1}
            className={`sf-btn-ghost flex items-center gap-2 ${currentStep === 1 ? 'opacity-50 cursor-not-allowed' : ''}`}>

            <ArrowLeftIcon className="w-4 h-4" />
            Back
          </button>

          <div className="flex items-center gap-2">
            {steps.map((step) =>
            <div
              key={step.number}
              className={`w-2 h-2 rounded-full ${currentStep >= step.number ? 'bg-[#7c3aed]' : 'bg-[#2d1f5e]'}`} />

            )}
          </div>

          <button
            onClick={nextStep}
            className="sf-btn-primary flex items-center gap-2">

            {currentStep === 4 ?
            <>
                <RocketIcon className="w-4 h-4" />
                Launch Dashboard
              </> :

            <>
                Continue
                <ArrowRightIcon className="w-4 h-4" />
              </>
            }
          </button>
        </div>
      </div>
    </div>);

}