import React from 'react';
import {
  CalendarIcon,
  DownloadIcon,
  TrendingUpIcon,
  TrendingDownIcon,
  AlertCircleIcon,
  CheckCircleIcon,
  ClockIcon,
  UsersIcon,
  ZapIcon,
  ArrowRightIcon } from
'lucide-react';
import {
  AreaChart,
  Area,
  BarChart,
  Bar,
  PieChart,
  Pie,
  Cell,
  ResponsiveContainer,
  XAxis,
  YAxis,
  Tooltip,
  Legend } from
'recharts';
// Weekly error trend data
const errorTrendData = [
{
  week: 'Week 1',
  errors: 1245,
  resolved: 1180
},
{
  week: 'Week 2',
  errors: 1456,
  resolved: 1320
},
{
  week: 'Week 3',
  errors: 1123,
  resolved: 1089
},
{
  week: 'Week 4',
  errors: 987,
  resolved: 945
}];

// Error distribution by type
const errorDistribution = [
{
  name: 'TypeError',
  value: 35,
  color: '#e91e8c'
},
{
  name: 'NetworkError',
  value: 25,
  color: '#7c3aed'
},
{
  name: 'SyntaxError',
  value: 15,
  color: '#f59e0b'
},
{
  name: 'ReferenceError',
  value: 12,
  color: '#22c55e'
},
{
  name: 'Other',
  value: 13,
  color: '#6b5f8a'
}];

// Performance metrics over time
const performanceData = [
{
  day: '1',
  p50: 120,
  p95: 245,
  p99: 450
},
{
  day: '5',
  p50: 115,
  p95: 238,
  p99: 420
},
{
  day: '10',
  p50: 125,
  p95: 252,
  p99: 480
},
{
  day: '15',
  p50: 118,
  p95: 240,
  p99: 445
},
{
  day: '20',
  p50: 122,
  p95: 248,
  p99: 460
},
{
  day: '25',
  p50: 110,
  p95: 235,
  p99: 410
},
{
  day: '30',
  p50: 108,
  p95: 230,
  p99: 395
}];

// Top issues
const topIssues = [
{
  id: 'ISS-1234',
  title: 'TypeError in UserList component',
  events: 2847,
  trend: -12
},
{
  id: 'ISS-1233',
  title: 'API timeout on checkout',
  events: 1523,
  trend: +8
},
{
  id: 'ISS-1232',
  title: 'Memory leak in WebSocket',
  events: 892,
  trend: -5
},
{
  id: 'ISS-1231',
  title: 'Slow database query',
  events: 456,
  trend: +15
},
{
  id: 'ISS-1230',
  title: 'CSS layout shift',
  events: 234,
  trend: -20
}];

// Key insights
const insights = [
{
  type: 'success',
  title: 'Error Rate Decreased',
  description: 'Overall error rate dropped by 18% compared to last month',
  icon: <TrendingDownIcon className="w-5 h-5" />
},
{
  type: 'warning',
  title: 'Performance Regression',
  description: 'P95 latency increased by 8ms in the checkout flow',
  icon: <ClockIcon className="w-5 h-5" />
},
{
  type: 'info',
  title: 'New Error Pattern',
  description: '15 new unique error types detected this month',
  icon: <AlertCircleIcon className="w-5 h-5" />
},
{
  type: 'success',
  title: 'Resolution Time Improved',
  description: 'Average time to resolve issues decreased by 2.3 hours',
  icon: <CheckCircleIcon className="w-5 h-5" />
}];

type StatCardProps = {
  title: string;
  value: string;
  change: string;
  isPositive: boolean;
  icon: React.ReactNode;
};
function StatCard({ title, value, change, isPositive, icon }: StatCardProps) {
  return (
    <div className="sf-card p-5">
      <div className="flex items-center justify-between mb-3">
        <span className="text-[#9b8fc2] text-sm font-medium">{title}</span>
        <div className="w-9 h-9 rounded-lg bg-[#2d1f5e] flex items-center justify-center text-[#7c3aed]">
          {icon}
        </div>
      </div>
      <p className="text-3xl font-bold text-[#e2dff0] mb-1">{value}</p>
      <div
        className={`flex items-center gap-1 text-sm ${isPositive ? 'text-[#22c55e]' : 'text-[#e91e8c]'}`}>

        {isPositive ?
        <TrendingUpIcon className="w-4 h-4" /> :

        <TrendingDownIcon className="w-4 h-4" />
        }
        {change} vs last month
      </div>
    </div>);

}
export function MonthlyReportPage() {
  return (
    <div className="min-h-screen">
      {/* Header */}
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-3xl font-bold text-[#e2dff0] mb-1">
            Monthly Report
          </h1>
          <p className="text-[#9b8fc2]">January 2024 Performance Summary</p>
        </div>
        <div className="flex items-center gap-3">
          <button className="sf-btn-secondary flex items-center gap-2">
            <CalendarIcon className="w-4 h-4" />
            January 2024
          </button>
          <button className="sf-btn-primary flex items-center gap-2">
            <DownloadIcon className="w-4 h-4" />
            Export PDF
          </button>
        </div>
      </div>

      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        <StatCard
          title="Total Errors"
          value="4,811"
          change="-18%"
          isPositive={true}
          icon={<AlertCircleIcon className="w-5 h-5" />} />

        <StatCard
          title="Resolved Issues"
          value="4,534"
          change="+12%"
          isPositive={true}
          icon={<CheckCircleIcon className="w-5 h-5" />} />

        <StatCard
          title="Avg Resolution Time"
          value="4.2h"
          change="-2.3h"
          isPositive={true}
          icon={<ClockIcon className="w-5 h-5" />} />

        <StatCard
          title="Affected Users"
          value="12.4K"
          change="-8%"
          isPositive={true}
          icon={<UsersIcon className="w-5 h-5" />} />

      </div>

      {/* Key Insights */}
      <div className="sf-card p-6 mb-8">
        <h2 className="text-xl font-semibold text-[#e2dff0] mb-4">
          Key Insights
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {insights.map((insight, index) =>
          <div
            key={index}
            className={`p-4 rounded-lg border ${insight.type === 'success' ? 'bg-[#22c55e]/10 border-[#22c55e]/30' : insight.type === 'warning' ? 'bg-[#f59e0b]/10 border-[#f59e0b]/30' : 'bg-[#7c3aed]/10 border-[#7c3aed]/30'}`}>

              <div
              className={`mb-2 ${insight.type === 'success' ? 'text-[#22c55e]' : insight.type === 'warning' ? 'text-[#f59e0b]' : 'text-[#7c3aed]'}`}>

                {insight.icon}
              </div>
              <h3 className="font-semibold text-[#e2dff0] mb-1">
                {insight.title}
              </h3>
              <p className="text-sm text-[#9b8fc2]">{insight.description}</p>
            </div>
          )}
        </div>
      </div>

      {/* Charts Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
        {/* Error Trend */}
        <div className="sf-card p-6">
          <h2 className="text-lg font-semibold text-[#e2dff0] mb-4">
            Weekly Error Trend
          </h2>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={errorTrendData}>
                <XAxis
                  dataKey="week"
                  axisLine={false}
                  tickLine={false}
                  tick={{
                    fill: '#6b5f8a',
                    fontSize: 12
                  }} />

                <YAxis
                  axisLine={false}
                  tickLine={false}
                  tick={{
                    fill: '#6b5f8a',
                    fontSize: 12
                  }} />

                <Tooltip
                  contentStyle={{
                    background: '#1a1333',
                    border: '1px solid rgba(124, 58, 237, 0.3)',
                    borderRadius: '8px',
                    color: '#e2dff0'
                  }} />

                <Legend />
                <Bar
                  dataKey="errors"
                  fill="#e91e8c"
                  radius={[4, 4, 0, 0]}
                  name="Total Errors" />

                <Bar
                  dataKey="resolved"
                  fill="#22c55e"
                  radius={[4, 4, 0, 0]}
                  name="Resolved" />

              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Error Distribution */}
        <div className="sf-card p-6">
          <h2 className="text-lg font-semibold text-[#e2dff0] mb-4">
            Error Distribution by Type
          </h2>
          <div className="h-64 flex items-center">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={errorDistribution}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={90}
                  paddingAngle={2}
                  dataKey="value">

                  {errorDistribution.map((entry, index) =>
                  <Cell key={`cell-${index}`} fill={entry.color} />
                  )}
                </Pie>
                <Tooltip
                  contentStyle={{
                    background: '#1a1333',
                    border: '1px solid rgba(124, 58, 237, 0.3)',
                    borderRadius: '8px',
                    color: '#e2dff0'
                  }} />

              </PieChart>
            </ResponsiveContainer>
            <div className="space-y-2">
              {errorDistribution.map((item) =>
              <div key={item.name} className="flex items-center gap-2">
                  <div
                  className="w-3 h-3 rounded-full"
                  style={{
                    background: item.color
                  }} />

                  <span className="text-sm text-[#9b8fc2]">{item.name}</span>
                  <span className="text-sm font-medium text-[#e2dff0]">
                    {item.value}%
                  </span>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Performance Chart */}
      <div className="sf-card p-6 mb-8">
        <h2 className="text-lg font-semibold text-[#e2dff0] mb-4">
          Latency Percentiles (ms)
        </h2>
        <div className="h-64">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={performanceData}>
              <defs>
                <linearGradient id="p50Gradient" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#22c55e" stopOpacity={0.3} />
                  <stop offset="100%" stopColor="#22c55e" stopOpacity={0} />
                </linearGradient>
                <linearGradient id="p95Gradient" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#7c3aed" stopOpacity={0.3} />
                  <stop offset="100%" stopColor="#7c3aed" stopOpacity={0} />
                </linearGradient>
                <linearGradient id="p99Gradient" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#e91e8c" stopOpacity={0.3} />
                  <stop offset="100%" stopColor="#e91e8c" stopOpacity={0} />
                </linearGradient>
              </defs>
              <XAxis
                dataKey="day"
                axisLine={false}
                tickLine={false}
                tick={{
                  fill: '#6b5f8a',
                  fontSize: 12
                }} />

              <YAxis
                axisLine={false}
                tickLine={false}
                tick={{
                  fill: '#6b5f8a',
                  fontSize: 12
                }} />

              <Tooltip
                contentStyle={{
                  background: '#1a1333',
                  border: '1px solid rgba(124, 58, 237, 0.3)',
                  borderRadius: '8px',
                  color: '#e2dff0'
                }} />

              <Legend />
              <Area
                type="monotone"
                dataKey="p99"
                stroke="#e91e8c"
                fill="url(#p99Gradient)"
                name="P99" />

              <Area
                type="monotone"
                dataKey="p95"
                stroke="#7c3aed"
                fill="url(#p95Gradient)"
                name="P95" />

              <Area
                type="monotone"
                dataKey="p50"
                stroke="#22c55e"
                fill="url(#p50Gradient)"
                name="P50" />

            </AreaChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Top Issues */}
      <div className="sf-card p-6">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-lg font-semibold text-[#e2dff0]">
            Top Issues This Month
          </h2>
          <button className="sf-btn-ghost text-sm flex items-center gap-1">
            View All <ArrowRightIcon className="w-4 h-4" />
          </button>
        </div>
        <div className="space-y-3">
          {topIssues.map((issue, index) =>
          <div
            key={issue.id}
            className="flex items-center justify-between p-4 rounded-lg bg-[#0f0a1e] hover:bg-[#2d1f5e]/30 transition-colors">

              <div className="flex items-center gap-4">
                <span className="text-2xl font-bold text-[#6b5f8a]">
                  #{index + 1}
                </span>
                <div>
                  <p className="font-medium text-[#e2dff0]">{issue.title}</p>
                  <p className="text-sm text-[#6b5f8a] font-mono">{issue.id}</p>
                </div>
              </div>
              <div className="flex items-center gap-6">
                <div className="text-right">
                  <p className="font-semibold text-[#e2dff0]">
                    {issue.events.toLocaleString()}
                  </p>
                  <p className="text-xs text-[#6b5f8a]">events</p>
                </div>
                <div
                className={`flex items-center gap-1 ${issue.trend < 0 ? 'text-[#22c55e]' : 'text-[#e91e8c]'}`}>

                  {issue.trend < 0 ?
                <TrendingDownIcon className="w-4 h-4" /> :

                <TrendingUpIcon className="w-4 h-4" />
                }
                  <span className="font-medium">{Math.abs(issue.trend)}%</span>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>);

}