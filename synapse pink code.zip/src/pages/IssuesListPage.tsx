import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import {
  SearchIcon,
  FilterIcon,
  ChevronDownIcon,
  ChevronLeftIcon,
  ChevronRightIcon,
  CheckIcon,
  AlertCircleIcon,
  AlertTriangleIcon,
  InfoIcon,
  CheckCircleIcon,
  MoreHorizontalIcon } from
'lucide-react';
type Issue = {
  id: string;
  title: string;
  status: 'open' | 'investigating' | 'resolved' | 'ignored';
  priority: 'critical' | 'high' | 'medium' | 'low';
  events: number;
  users: number;
  lastSeen: string;
  firstSeen: string;
  assignee: {
    name: string;
    initials: string;
  } | null;
  selected?: boolean;
};
const mockIssues: Issue[] = [
{
  id: 'ISS-1234',
  title: 'TypeError: Cannot read property "map" of undefined',
  status: 'open',
  priority: 'critical',
  events: 2847,
  users: 1234,
  lastSeen: '2 min ago',
  firstSeen: '2 days ago',
  assignee: {
    name: 'Sarah Chen',
    initials: 'SC'
  }
},
{
  id: 'ISS-1233',
  title: 'API timeout on /api/checkout endpoint',
  status: 'investigating',
  priority: 'high',
  events: 1523,
  users: 892,
  lastSeen: '15 min ago',
  firstSeen: '1 day ago',
  assignee: {
    name: 'Mike Ross',
    initials: 'MR'
  }
},
{
  id: 'ISS-1232',
  title: 'Memory leak in WebSocket connection handler',
  status: 'open',
  priority: 'high',
  events: 892,
  users: 456,
  lastSeen: '1 hour ago',
  firstSeen: '3 days ago',
  assignee: {
    name: 'Alex Kim',
    initials: 'AK'
  }
},
{
  id: 'ISS-1231',
  title: 'Slow database query on user dashboard',
  status: 'investigating',
  priority: 'medium',
  events: 456,
  users: 234,
  lastSeen: '2 hours ago',
  firstSeen: '5 days ago',
  assignee: {
    name: 'John Doe',
    initials: 'JD'
  }
},
{
  id: 'ISS-1230',
  title: 'CSS layout shift on mobile navigation',
  status: 'open',
  priority: 'low',
  events: 234,
  users: 156,
  lastSeen: '4 hours ago',
  firstSeen: '1 week ago',
  assignee: {
    name: 'Emma Wilson',
    initials: 'EW'
  }
},
{
  id: 'ISS-1229',
  title: 'Unhandled promise rejection in auth flow',
  status: 'resolved',
  priority: 'critical',
  events: 5621,
  users: 2341,
  lastSeen: '1 day ago',
  firstSeen: '2 weeks ago',
  assignee: {
    name: 'Sarah Chen',
    initials: 'SC'
  }
},
{
  id: 'ISS-1228',
  title: 'Rate limiting not working correctly',
  status: 'open',
  priority: 'high',
  events: 789,
  users: 345,
  lastSeen: '3 hours ago',
  firstSeen: '4 days ago',
  assignee: null
},
{
  id: 'ISS-1227',
  title: 'Image optimization failing for large files',
  status: 'ignored',
  priority: 'low',
  events: 123,
  users: 67,
  lastSeen: '2 days ago',
  firstSeen: '3 weeks ago',
  assignee: {
    name: 'Mike Ross',
    initials: 'MR'
  }
},
{
  id: 'ISS-1226',
  title: 'Session expiry not handled gracefully',
  status: 'open',
  priority: 'medium',
  events: 567,
  users: 289,
  lastSeen: '5 hours ago',
  firstSeen: '1 week ago',
  assignee: {
    name: 'Alex Kim',
    initials: 'AK'
  }
},
{
  id: 'ISS-1225',
  title: 'Search indexing delay causing stale results',
  status: 'investigating',
  priority: 'medium',
  events: 345,
  users: 178,
  lastSeen: '6 hours ago',
  firstSeen: '2 weeks ago',
  assignee: {
    name: 'John Doe',
    initials: 'JD'
  }
}];

function StatusIcon({ status }: {status: Issue['status'];}) {
  switch (status) {
    case 'open':
      return <AlertCircleIcon className="w-4 h-4 text-[#e91e8c]" />;
    case 'investigating':
      return <AlertTriangleIcon className="w-4 h-4 text-[#f59e0b]" />;
    case 'resolved':
      return <CheckCircleIcon className="w-4 h-4 text-[#22c55e]" />;
    case 'ignored':
      return <InfoIcon className="w-4 h-4 text-[#6b5f8a]" />;
    default:
      return null;
  }
}
function PriorityBadge({ priority }: {priority: Issue['priority'];}) {
  const styles: Record<string, string> = {
    critical: 'sf-badge-critical',
    high: 'sf-badge-high',
    medium: 'sf-badge-medium',
    low: 'sf-badge-low'
  };
  return (
    <span className={`sf-badge ${styles[priority]}`}>
      {priority.charAt(0).toUpperCase() + priority.slice(1)}
    </span>);

}
function FilterDropdown({
  label,
  options



}: {label: string;options: string[];}) {
  const [isOpen, setIsOpen] = useState(false);
  const [selected, setSelected] = useState<string | null>(null);
  return (
    <div className="relative">
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="sf-btn-secondary flex items-center gap-2 text-sm">

        {selected || label}
        <ChevronDownIcon className="w-4 h-4" />
      </button>
      {isOpen &&
      <>
          <div
          className="fixed inset-0 z-10"
          onClick={() => setIsOpen(false)} />

          <div className="absolute top-full left-0 mt-2 w-48 bg-[#1a1333] border border-[rgba(124,58,237,0.3)] rounded-lg shadow-xl z-20 py-1">
            <button
            onClick={() => {
              setSelected(null);
              setIsOpen(false);
            }}
            className="w-full px-4 py-2 text-left text-sm text-[#9b8fc2] hover:bg-[#7c3aed]/10 hover:text-[#e2dff0]">

              All
            </button>
            {options.map((option) =>
          <button
            key={option}
            onClick={() => {
              setSelected(option);
              setIsOpen(false);
            }}
            className="w-full px-4 py-2 text-left text-sm text-[#9b8fc2] hover:bg-[#7c3aed]/10 hover:text-[#e2dff0] flex items-center justify-between">

                {option}
                {selected === option &&
            <CheckIcon className="w-4 h-4 text-[#7c3aed]" />
            }
              </button>
          )}
          </div>
        </>
      }
    </div>);

}
export function IssuesListPage() {
  const [issues, setIssues] = useState(mockIssues);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectAll, setSelectAll] = useState(false);
  const toggleSelectAll = () => {
    setSelectAll(!selectAll);
    setIssues(
      issues.map((issue) => ({
        ...issue,
        selected: !selectAll
      }))
    );
  };
  const toggleSelect = (id: string) => {
    setIssues(
      issues.map((issue) =>
      issue.id === id ?
      {
        ...issue,
        selected: !issue.selected
      } :
      issue
      )
    );
  };
  const selectedCount = issues.filter((i) => i.selected).length;
  return (
    <div className="min-h-screen">
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-3xl font-bold text-[#e2dff0] mb-1">Issues</h1>
          <p className="text-[#9b8fc2]">
            Track and resolve errors across your application
          </p>
        </div>
        <button className="sf-btn-primary">Create Issue</button>
      </div>

      {/* Filters and Search */}
      <div className="sf-card p-4 mb-6">
        <div className="flex flex-wrap items-center gap-4">
          <div className="relative flex-1 min-w-[240px]">
            <SearchIcon className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-[#6b5f8a]" />
            <input
              type="text"
              placeholder="Search issues..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="sf-input pl-10" />

          </div>
          <FilterDropdown
            label="Status"
            options={['Open', 'Investigating', 'Resolved', 'Ignored']} />

          <FilterDropdown
            label="Priority"
            options={['Critical', 'High', 'Medium', 'Low']} />

          <FilterDropdown
            label="Assignee"
            options={[
            'Sarah Chen',
            'Mike Ross',
            'Alex Kim',
            'John Doe',
            'Emma Wilson',
            'Unassigned']
            } />

          <button className="sf-btn-ghost flex items-center gap-2 text-sm">
            <FilterIcon className="w-4 h-4" />
            More Filters
          </button>
        </div>
      </div>

      {/* Bulk Actions */}
      {selectedCount > 0 &&
      <div className="sf-card p-3 mb-4 flex items-center gap-4 bg-[#7c3aed]/10 border-[#7c3aed]/40">
          <span className="text-sm text-[#e2dff0]">
            {selectedCount} selected
          </span>
          <button className="sf-btn-secondary text-sm py-1.5">Resolve</button>
          <button className="sf-btn-secondary text-sm py-1.5">Ignore</button>
          <button className="sf-btn-secondary text-sm py-1.5">Assign</button>
          <button className="sf-btn-ghost text-sm py-1.5 text-[#e91e8c]">
            Delete
          </button>
        </div>
      }

      {/* Issues Table */}
      <div className="sf-card overflow-hidden">
        <table className="w-full">
          <thead>
            <tr className="border-b border-[rgba(124,58,237,0.2)]">
              <th className="p-4 text-left">
                <button
                  onClick={toggleSelectAll}
                  className={`w-5 h-5 rounded border-2 flex items-center justify-center transition-all ${selectAll ? 'bg-[#7c3aed] border-[#7c3aed]' : 'border-[rgba(124,58,237,0.4)] hover:border-[#7c3aed]'}`}>

                  {selectAll && <CheckIcon className="w-3 h-3 text-white" />}
                </button>
              </th>
              <th className="p-4 text-left text-xs font-semibold text-[#9b8fc2] uppercase tracking-wider">
                Issue
              </th>
              <th className="p-4 text-left text-xs font-semibold text-[#9b8fc2] uppercase tracking-wider">
                Priority
              </th>
              <th className="p-4 text-left text-xs font-semibold text-[#9b8fc2] uppercase tracking-wider">
                Events
              </th>
              <th className="p-4 text-left text-xs font-semibold text-[#9b8fc2] uppercase tracking-wider">
                Users
              </th>
              <th className="p-4 text-left text-xs font-semibold text-[#9b8fc2] uppercase tracking-wider">
                Assignee
              </th>
              <th className="p-4 text-left text-xs font-semibold text-[#9b8fc2] uppercase tracking-wider">
                Last Seen
              </th>
              <th className="p-4"></th>
            </tr>
          </thead>
          <tbody>
            {issues.map((issue) =>
            <tr
              key={issue.id}
              className="border-b border-[rgba(124,58,237,0.1)] hover:bg-[#7c3aed]/5 transition-colors group">

                <td className="p-4">
                  <button
                  onClick={() => toggleSelect(issue.id)}
                  className={`w-5 h-5 rounded border-2 flex items-center justify-center transition-all ${issue.selected ? 'bg-[#7c3aed] border-[#7c3aed]' : 'border-[rgba(124,58,237,0.4)] hover:border-[#7c3aed]'}`}>

                    {issue.selected &&
                  <CheckIcon className="w-3 h-3 text-white" />
                  }
                  </button>
                </td>
                <td className="p-4">
                  <Link to={`/issues/${issue.id}`} className="block">
                    <div className="flex items-center gap-3">
                      <StatusIcon status={issue.status} />
                      <div>
                        <p className="text-sm font-medium text-[#e2dff0] group-hover:text-[#7c3aed] transition-colors line-clamp-1">
                          {issue.title}
                        </p>
                        <p className="text-xs text-[#6b5f8a] font-mono">
                          {issue.id}
                        </p>
                      </div>
                    </div>
                  </Link>
                </td>
                <td className="p-4">
                  <PriorityBadge priority={issue.priority} />
                </td>
                <td className="p-4 text-sm text-[#9b8fc2]">
                  {issue.events.toLocaleString()}
                </td>
                <td className="p-4 text-sm text-[#9b8fc2]">
                  {issue.users.toLocaleString()}
                </td>
                <td className="p-4">
                  {issue.assignee ?
                <div className="flex items-center gap-2">
                      <div className="w-7 h-7 rounded-full bg-gradient-to-br from-[#e91e8c] to-[#7c3aed] flex items-center justify-center text-white text-xs font-medium">
                        {issue.assignee.initials}
                      </div>
                      <span className="text-sm text-[#9b8fc2]">
                        {issue.assignee.name}
                      </span>
                    </div> :

                <span className="text-sm text-[#6b5f8a]">Unassigned</span>
                }
                </td>
                <td className="p-4 text-sm text-[#9b8fc2]">{issue.lastSeen}</td>
                <td className="p-4">
                  <button className="p-2 rounded-lg text-[#6b5f8a] hover:text-[#e2dff0] hover:bg-[#7c3aed]/10 opacity-0 group-hover:opacity-100 transition-all">
                    <MoreHorizontalIcon className="w-4 h-4" />
                  </button>
                </td>
              </tr>
            )}
          </tbody>
        </table>

        {/* Pagination */}
        <div className="p-4 border-t border-[rgba(124,58,237,0.2)] flex items-center justify-between">
          <p className="text-sm text-[#9b8fc2]">
            Showing <span className="font-medium text-[#e2dff0]">1-10</span> of{' '}
            <span className="font-medium text-[#e2dff0]">248</span> issues
          </p>
          <div className="flex items-center gap-2">
            <button className="sf-btn-secondary p-2">
              <ChevronLeftIcon className="w-4 h-4" />
            </button>
            <button className="w-9 h-9 rounded-lg bg-[#7c3aed] text-white font-medium text-sm">
              1
            </button>
            <button className="w-9 h-9 rounded-lg text-[#9b8fc2] hover:bg-[#7c3aed]/10 font-medium text-sm">
              2
            </button>
            <button className="w-9 h-9 rounded-lg text-[#9b8fc2] hover:bg-[#7c3aed]/10 font-medium text-sm">
              3
            </button>
            <span className="text-[#6b5f8a]">...</span>
            <button className="w-9 h-9 rounded-lg text-[#9b8fc2] hover:bg-[#7c3aed]/10 font-medium text-sm">
              25
            </button>
            <button className="sf-btn-secondary p-2">
              <ChevronRightIcon className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </div>);

}