import React, { useState } from 'react';
import {
  UserIcon,
  BellIcon,
  ShieldIcon,
  PaletteIcon,
  KeyIcon,
  UsersIcon,
  WebhookIcon,
  CreditCardIcon,
  SaveIcon,
  CameraIcon,
  CheckIcon,
  TrashIcon,
  PlusIcon } from
'lucide-react';
type Tab =
'profile' |
'notifications' |
'security' |
'appearance' |
'team' |
'integrations' |
'billing';
const tabs: {
  id: Tab;
  label: string;
  icon: React.ReactNode;
}[] = [
{
  id: 'profile',
  label: 'Profile',
  icon: <UserIcon className="w-4 h-4" />
},
{
  id: 'notifications',
  label: 'Notifications',
  icon: <BellIcon className="w-4 h-4" />
},
{
  id: 'security',
  label: 'Security',
  icon: <ShieldIcon className="w-4 h-4" />
},
{
  id: 'appearance',
  label: 'Appearance',
  icon: <PaletteIcon className="w-4 h-4" />
},
{
  id: 'team',
  label: 'Team',
  icon: <UsersIcon className="w-4 h-4" />
},
{
  id: 'integrations',
  label: 'Integrations',
  icon: <WebhookIcon className="w-4 h-4" />
},
{
  id: 'billing',
  label: 'Billing',
  icon: <CreditCardIcon className="w-4 h-4" />
}];

// Mock team members
const teamMembers = [
{
  name: 'Sarah Chen',
  email: 'sarah@synapseflow.io',
  role: 'Admin',
  initials: 'SC'
},
{
  name: 'Mike Ross',
  email: 'mike@synapseflow.io',
  role: 'Developer',
  initials: 'MR'
},
{
  name: 'Alex Kim',
  email: 'alex@synapseflow.io',
  role: 'Developer',
  initials: 'AK'
},
{
  name: 'Emma Wilson',
  email: 'emma@synapseflow.io',
  role: 'Viewer',
  initials: 'EW'
}];

// Mock integrations
const integrations = [
{
  name: 'GitHub',
  description: 'Connect your repositories',
  connected: true,
  icon: '🐙'
},
{
  name: 'Slack',
  description: 'Get notifications in Slack',
  connected: true,
  icon: '💬'
},
{
  name: 'Jira',
  description: 'Sync issues with Jira',
  connected: false,
  icon: '📋'
},
{
  name: 'PagerDuty',
  description: 'Alert on-call engineers',
  connected: false,
  icon: '🚨'
},
{
  name: 'Figma',
  description: 'Review design files',
  connected: true,
  icon: '🎨'
}];

export function SettingsPage() {
  const [activeTab, setActiveTab] = useState<Tab>('profile');
  const [notifications, setNotifications] = useState({
    email: true,
    push: true,
    slack: false,
    critical: true,
    weekly: true
  });
  return (
    <div className="min-h-screen">
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-[#e2dff0] mb-1">Settings</h1>
        <p className="text-[#9b8fc2]">Manage your account and preferences</p>
      </div>

      <div className="flex gap-6">
        {/* Sidebar Tabs */}
        <div className="w-56 flex-shrink-0">
          <nav className="sf-card p-2 space-y-1">
            {tabs.map((tab) =>
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg transition-all text-left ${activeTab === tab.id ? 'bg-[#7c3aed]/20 text-[#e2dff0] border border-[#7c3aed]/40' : 'text-[#9b8fc2] hover:bg-[#7c3aed]/10 hover:text-[#e2dff0] border border-transparent'}`}>

                <span className={activeTab === tab.id ? 'text-[#7c3aed]' : ''}>
                  {tab.icon}
                </span>
                <span className="font-medium">{tab.label}</span>
              </button>
            )}
          </nav>
        </div>

        {/* Content */}
        <div className="flex-1">
          {activeTab === 'profile' &&
          <div className="sf-card p-6">
              <h2 className="text-xl font-semibold text-[#e2dff0] mb-6">
                Profile Settings
              </h2>

              {/* Avatar */}
              <div className="flex items-center gap-6 mb-8">
                <div className="relative">
                  <div className="w-24 h-24 rounded-full bg-gradient-to-br from-[#e91e8c] to-[#7c3aed] flex items-center justify-center text-white text-3xl font-bold">
                    JD
                  </div>
                  <button className="absolute bottom-0 right-0 w-8 h-8 rounded-full bg-[#2d1f5e] border border-[rgba(124,58,237,0.3)] flex items-center justify-center text-[#9b8fc2] hover:text-[#e2dff0] transition-colors">
                    <CameraIcon className="w-4 h-4" />
                  </button>
                </div>
                <div>
                  <h3 className="font-semibold text-[#e2dff0]">
                    Profile Photo
                  </h3>
                  <p className="text-sm text-[#9b8fc2] mb-2">
                    JPG, PNG or GIF. Max 2MB.
                  </p>
                  <button className="sf-btn-secondary text-sm">
                    Upload New
                  </button>
                </div>
              </div>

              {/* Form */}
              <div className="space-y-6">
                <div className="grid grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm font-medium text-[#9b8fc2] mb-2">
                      First Name
                    </label>
                    <input
                    type="text"
                    defaultValue="John"
                    className="sf-input" />

                  </div>
                  <div>
                    <label className="block text-sm font-medium text-[#9b8fc2] mb-2">
                      Last Name
                    </label>
                    <input
                    type="text"
                    defaultValue="Doe"
                    className="sf-input" />

                  </div>
                </div>
                <div>
                  <label className="block text-sm font-medium text-[#9b8fc2] mb-2">
                    Email
                  </label>
                  <input
                  type="email"
                  defaultValue="john@synapseflow.io"
                  className="sf-input" />

                </div>
                <div>
                  <label className="block text-sm font-medium text-[#9b8fc2] mb-2">
                    Job Title
                  </label>
                  <input
                  type="text"
                  defaultValue="Senior Software Engineer"
                  className="sf-input" />

                </div>
                <div>
                  <label className="block text-sm font-medium text-[#9b8fc2] mb-2">
                    Bio
                  </label>
                  <textarea
                  rows={3}
                  defaultValue="Building great software and fixing bugs."
                  className="sf-input resize-none" />

                </div>
                <div className="flex justify-end">
                  <button className="sf-btn-primary flex items-center gap-2">
                    <SaveIcon className="w-4 h-4" />
                    Save Changes
                  </button>
                </div>
              </div>
            </div>
          }

          {activeTab === 'notifications' &&
          <div className="sf-card p-6">
              <h2 className="text-xl font-semibold text-[#e2dff0] mb-6">
                Notification Preferences
              </h2>

              <div className="space-y-6">
                {/* Email Notifications */}
                <div className="flex items-center justify-between p-4 bg-[#0f0a1e] rounded-lg">
                  <div>
                    <h3 className="font-medium text-[#e2dff0]">
                      Email Notifications
                    </h3>
                    <p className="text-sm text-[#9b8fc2]">
                      Receive updates via email
                    </p>
                  </div>
                  <button
                  onClick={() =>
                  setNotifications({
                    ...notifications,
                    email: !notifications.email
                  })
                  }
                  className={`w-12 h-6 rounded-full transition-colors ${notifications.email ? 'bg-[#7c3aed]' : 'bg-[#2d1f5e]'}`}>

                    <div
                    className={`w-5 h-5 rounded-full bg-white transition-transform ${notifications.email ? 'translate-x-6' : 'translate-x-0.5'}`} />

                  </button>
                </div>

                {/* Push Notifications */}
                <div className="flex items-center justify-between p-4 bg-[#0f0a1e] rounded-lg">
                  <div>
                    <h3 className="font-medium text-[#e2dff0]">
                      Push Notifications
                    </h3>
                    <p className="text-sm text-[#9b8fc2]">
                      Receive browser push notifications
                    </p>
                  </div>
                  <button
                  onClick={() =>
                  setNotifications({
                    ...notifications,
                    push: !notifications.push
                  })
                  }
                  className={`w-12 h-6 rounded-full transition-colors ${notifications.push ? 'bg-[#7c3aed]' : 'bg-[#2d1f5e]'}`}>

                    <div
                    className={`w-5 h-5 rounded-full bg-white transition-transform ${notifications.push ? 'translate-x-6' : 'translate-x-0.5'}`} />

                  </button>
                </div>

                {/* Slack Notifications */}
                <div className="flex items-center justify-between p-4 bg-[#0f0a1e] rounded-lg">
                  <div>
                    <h3 className="font-medium text-[#e2dff0]">
                      Slack Notifications
                    </h3>
                    <p className="text-sm text-[#9b8fc2]">
                      Get notified in your Slack workspace
                    </p>
                  </div>
                  <button
                  onClick={() =>
                  setNotifications({
                    ...notifications,
                    slack: !notifications.slack
                  })
                  }
                  className={`w-12 h-6 rounded-full transition-colors ${notifications.slack ? 'bg-[#7c3aed]' : 'bg-[#2d1f5e]'}`}>

                    <div
                    className={`w-5 h-5 rounded-full bg-white transition-transform ${notifications.slack ? 'translate-x-6' : 'translate-x-0.5'}`} />

                  </button>
                </div>

                {/* Critical Alerts */}
                <div className="flex items-center justify-between p-4 bg-[#0f0a1e] rounded-lg">
                  <div>
                    <h3 className="font-medium text-[#e2dff0]">
                      Critical Alerts
                    </h3>
                    <p className="text-sm text-[#9b8fc2]">
                      Always notify for critical issues
                    </p>
                  </div>
                  <button
                  onClick={() =>
                  setNotifications({
                    ...notifications,
                    critical: !notifications.critical
                  })
                  }
                  className={`w-12 h-6 rounded-full transition-colors ${notifications.critical ? 'bg-[#e91e8c]' : 'bg-[#2d1f5e]'}`}>

                    <div
                    className={`w-5 h-5 rounded-full bg-white transition-transform ${notifications.critical ? 'translate-x-6' : 'translate-x-0.5'}`} />

                  </button>
                </div>

                {/* Weekly Digest */}
                <div className="flex items-center justify-between p-4 bg-[#0f0a1e] rounded-lg">
                  <div>
                    <h3 className="font-medium text-[#e2dff0]">
                      Weekly Digest
                    </h3>
                    <p className="text-sm text-[#9b8fc2]">
                      Receive a weekly summary email
                    </p>
                  </div>
                  <button
                  onClick={() =>
                  setNotifications({
                    ...notifications,
                    weekly: !notifications.weekly
                  })
                  }
                  className={`w-12 h-6 rounded-full transition-colors ${notifications.weekly ? 'bg-[#7c3aed]' : 'bg-[#2d1f5e]'}`}>

                    <div
                    className={`w-5 h-5 rounded-full bg-white transition-transform ${notifications.weekly ? 'translate-x-6' : 'translate-x-0.5'}`} />

                  </button>
                </div>
              </div>
            </div>
          }

          {activeTab === 'security' &&
          <div className="space-y-6">
              <div className="sf-card p-6">
                <h2 className="text-xl font-semibold text-[#e2dff0] mb-6">
                  Password
                </h2>
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-[#9b8fc2] mb-2">
                      Current Password
                    </label>
                    <input
                    type="password"
                    className="sf-input"
                    placeholder="••••••••" />

                  </div>
                  <div>
                    <label className="block text-sm font-medium text-[#9b8fc2] mb-2">
                      New Password
                    </label>
                    <input
                    type="password"
                    className="sf-input"
                    placeholder="••••••••" />

                  </div>
                  <div>
                    <label className="block text-sm font-medium text-[#9b8fc2] mb-2">
                      Confirm New Password
                    </label>
                    <input
                    type="password"
                    className="sf-input"
                    placeholder="••••••••" />

                  </div>
                  <button className="sf-btn-primary">Update Password</button>
                </div>
              </div>

              <div className="sf-card p-6">
                <h2 className="text-xl font-semibold text-[#e2dff0] mb-4">
                  Two-Factor Authentication
                </h2>
                <p className="text-[#9b8fc2] mb-4">
                  Add an extra layer of security to your account
                </p>
                <button className="sf-btn-secondary flex items-center gap-2">
                  <KeyIcon className="w-4 h-4" />
                  Enable 2FA
                </button>
              </div>

              <div className="sf-card p-6">
                <h2 className="text-xl font-semibold text-[#e2dff0] mb-4">
                  Active Sessions
                </h2>
                <div className="space-y-3">
                  <div className="flex items-center justify-between p-3 bg-[#0f0a1e] rounded-lg">
                    <div>
                      <p className="font-medium text-[#e2dff0]">
                        Chrome on macOS
                      </p>
                      <p className="text-sm text-[#6b5f8a]">
                        San Francisco, CA • Current session
                      </p>
                    </div>
                    <span className="text-xs text-[#22c55e]">Active</span>
                  </div>
                  <div className="flex items-center justify-between p-3 bg-[#0f0a1e] rounded-lg">
                    <div>
                      <p className="font-medium text-[#e2dff0]">
                        Safari on iPhone
                      </p>
                      <p className="text-sm text-[#6b5f8a]">
                        San Francisco, CA • 2 hours ago
                      </p>
                    </div>
                    <button className="text-xs text-[#e91e8c] hover:underline">
                      Revoke
                    </button>
                  </div>
                </div>
              </div>
            </div>
          }

          {activeTab === 'team' &&
          <div className="sf-card p-6">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-xl font-semibold text-[#e2dff0]">
                  Team Members
                </h2>
                <button className="sf-btn-primary flex items-center gap-2">
                  <PlusIcon className="w-4 h-4" />
                  Invite Member
                </button>
              </div>

              <div className="space-y-3">
                {teamMembers.map((member) =>
              <div
                key={member.email}
                className="flex items-center justify-between p-4 bg-[#0f0a1e] rounded-lg">

                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-full bg-gradient-to-br from-[#e91e8c] to-[#7c3aed] flex items-center justify-center text-white font-medium">
                        {member.initials}
                      </div>
                      <div>
                        <p className="font-medium text-[#e2dff0]">
                          {member.name}
                        </p>
                        <p className="text-sm text-[#6b5f8a]">{member.email}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-4">
                      <select className="sf-input py-1.5 px-3 text-sm w-32">
                        <option
                      value="admin"
                      selected={member.role === 'Admin'}>

                          Admin
                        </option>
                        <option
                      value="developer"
                      selected={member.role === 'Developer'}>

                          Developer
                        </option>
                        <option
                      value="viewer"
                      selected={member.role === 'Viewer'}>

                          Viewer
                        </option>
                      </select>
                      <button className="p-2 text-[#6b5f8a] hover:text-[#e91e8c] transition-colors">
                        <TrashIcon className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
              )}
              </div>
            </div>
          }

          {activeTab === 'integrations' &&
          <div className="sf-card p-6">
              <h2 className="text-xl font-semibold text-[#e2dff0] mb-6">
                Integrations
              </h2>
              <div className="space-y-4">
                {integrations.map((integration) =>
              <div
                key={integration.name}
                className="flex items-center justify-between p-4 bg-[#0f0a1e] rounded-lg">

                    <div className="flex items-center gap-4">
                      <div className="w-12 h-12 rounded-lg bg-[#2d1f5e] flex items-center justify-center text-2xl">
                        {integration.icon}
                      </div>
                      <div>
                        <p className="font-medium text-[#e2dff0]">
                          {integration.name}
                        </p>
                        <p className="text-sm text-[#6b5f8a]">
                          {integration.description}
                        </p>
                      </div>
                    </div>
                    {integration.connected ?
                <div className="flex items-center gap-3">
                        <span className="flex items-center gap-1 text-sm text-[#22c55e]">
                          <CheckIcon className="w-4 h-4" />
                          Connected
                        </span>
                        <button className="sf-btn-ghost text-sm text-[#e91e8c]">
                          Disconnect
                        </button>
                      </div> :

                <button className="sf-btn-secondary text-sm">
                        Connect
                      </button>
                }
                  </div>
              )}
              </div>
            </div>
          }

          {activeTab === 'billing' &&
          <div className="space-y-6">
              <div className="sf-card p-6">
                <h2 className="text-xl font-semibold text-[#e2dff0] mb-4">
                  Current Plan
                </h2>
                <div className="flex items-center justify-between p-4 bg-gradient-to-r from-[#e91e8c]/20 to-[#7c3aed]/20 rounded-lg border border-[#7c3aed]/40">
                  <div>
                    <p className="text-2xl font-bold sf-gradient-text">
                      Pro Plan
                    </p>
                    <p className="text-[#9b8fc2]">$29/month • Billed monthly</p>
                  </div>
                  <button className="sf-btn-secondary">Upgrade</button>
                </div>
              </div>

              <div className="sf-card p-6">
                <h2 className="text-xl font-semibold text-[#e2dff0] mb-4">
                  Payment Method
                </h2>
                <div className="flex items-center justify-between p-4 bg-[#0f0a1e] rounded-lg">
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-8 bg-[#2d1f5e] rounded flex items-center justify-center text-[#9b8fc2]">
                      <CreditCardIcon className="w-5 h-5" />
                    </div>
                    <div>
                      <p className="font-medium text-[#e2dff0]">
                        •••• •••• •••• 4242
                      </p>
                      <p className="text-sm text-[#6b5f8a]">Expires 12/25</p>
                    </div>
                  </div>
                  <button className="sf-btn-ghost text-sm">Update</button>
                </div>
              </div>

              <div className="sf-card p-6">
                <h2 className="text-xl font-semibold text-[#e2dff0] mb-4">
                  Billing History
                </h2>
                <div className="space-y-2">
                  {[
                {
                  date: 'Jan 1, 2024',
                  amount: '$29.00',
                  status: 'Paid'
                },
                {
                  date: 'Dec 1, 2023',
                  amount: '$29.00',
                  status: 'Paid'
                },
                {
                  date: 'Nov 1, 2023',
                  amount: '$29.00',
                  status: 'Paid'
                }].
                map((invoice, i) =>
                <div
                  key={i}
                  className="flex items-center justify-between p-3 bg-[#0f0a1e] rounded-lg">

                      <span className="text-[#9b8fc2]">{invoice.date}</span>
                      <span className="text-[#e2dff0]">{invoice.amount}</span>
                      <span className="text-[#22c55e] text-sm">
                        {invoice.status}
                      </span>
                      <button className="text-[#7c3aed] text-sm hover:underline">
                        Download
                      </button>
                    </div>
                )}
                </div>
              </div>
            </div>
          }

          {activeTab === 'appearance' &&
          <div className="sf-card p-6">
              <h2 className="text-xl font-semibold text-[#e2dff0] mb-6">
                Appearance
              </h2>
              <div className="space-y-6">
                <div>
                  <label className="block text-sm font-medium text-[#9b8fc2] mb-3">
                    Theme
                  </label>
                  <div className="grid grid-cols-3 gap-4">
                    <button className="p-4 rounded-lg bg-[#0f0a1e] border-2 border-[#7c3aed] text-center">
                      <div className="w-full h-20 rounded bg-[#0f0a1e] mb-2 border border-[rgba(124,58,237,0.3)]" />
                      <span className="text-sm text-[#e2dff0]">Dark</span>
                    </button>
                    <button className="p-4 rounded-lg bg-[#0f0a1e] border-2 border-transparent hover:border-[rgba(124,58,237,0.3)] text-center">
                      <div className="w-full h-20 rounded bg-white mb-2" />
                      <span className="text-sm text-[#9b8fc2]">Light</span>
                    </button>
                    <button className="p-4 rounded-lg bg-[#0f0a1e] border-2 border-transparent hover:border-[rgba(124,58,237,0.3)] text-center">
                      <div className="w-full h-20 rounded bg-gradient-to-b from-white to-[#0f0a1e] mb-2" />
                      <span className="text-sm text-[#9b8fc2]">System</span>
                    </button>
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-[#9b8fc2] mb-3">
                    Accent Color
                  </label>
                  <div className="flex gap-3">
                    {[
                  '#e91e8c',
                  '#7c3aed',
                  '#22c55e',
                  '#f59e0b',
                  '#3b82f6'].
                  map((color) =>
                  <button
                    key={color}
                    className={`w-10 h-10 rounded-full ${color === '#7c3aed' ? 'ring-2 ring-white ring-offset-2 ring-offset-[#1a1333]' : ''}`}
                    style={{
                      background: color
                    }} />

                  )}
                  </div>
                </div>
              </div>
            </div>
          }
        </div>
      </div>
    </div>);

}