import React, { useState } from 'react';
import {
  XIcon,
  AlertTriangleIcon,
  TrendingUpIcon,
  TrendingDownIcon,
  ActivityIcon,
  UsersIcon,
  ClockIcon,
  ZapIcon,
  ChevronRightIcon,
  CalendarIcon } from
'lucide-react';
import {
  AreaChart,
  Area,
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip } from
'recharts';
import { Link } from 'react-router-dom';
// Sparkline data for metric cards
const eventsSparkline = [
{
  value: 800
},
{
  value: 920
},
{
  value: 850
},
{
  value: 1100
},
{
  value: 980
},
{
  value: 1050
},
{
  value: 1200
},
{
  value: 1150
},
{
  value: 1180
},
{
  value: 1200
}];

const errorSparkline = [
{
  value: 4.2
},
{
  value: 3.8
},
{
  value: 4.0
},
{
  value: 3.5
},
{
  value: 3.3
},
{
  value: 3.6
},
{
  value: 3.4
},
{
  value: 3.2
},
{
  value: 3.1
},
{
  value: 3.2
}];

const latencySparkline = [
{
  value: 220
},
{
  value: 235
},
{
  value: 228
},
{
  value: 240
},
{
  value: 238
},
{
  value: 242
},
{
  value: 250
},
{
  value: 248
},
{
  value: 245
},
{
  value: 245
}];

const usersSparkline = [
{
  value: 42
},
{
  value: 44
},
{
  value: 43
},
{
  value: 45
},
{
  value: 46
},
{
  value: 45
},
{
  value: 47
},
{
  value: 48
},
{
  value: 47
},
{
  value: 48.2
}];

// Funnel data
const funnelData = [
{
  name: 'Page View',
  value: 125000,
  percent: 100
},
{
  name: 'Sign Up Click',
  value: 45000,
  percent: 36
},
{
  name: 'Form Started',
  value: 28000,
  percent: 22.4
},
{
  name: 'Form Completed',
  value: 12500,
  percent: 10
},
{
  name: 'Converted',
  value: 8200,
  percent: 6.6
}];

// Recent issues
const recentIssues = [
{
  id: 'ISS-1234',
  title: 'TypeError: Cannot read property "map" of undefined',
  severity: 'critical',
  events: 2847,
  lastSeen: '2 min ago',
  assignee: {
    name: 'Sarah Chen',
    initials: 'SC'
  }
},
{
  id: 'ISS-1233',
  title: 'API timeout on /api/checkout endpoint',
  severity: 'high',
  events: 1523,
  lastSeen: '15 min ago',
  assignee: {
    name: 'Mike Ross',
    initials: 'MR'
  }
},
{
  id: 'ISS-1232',
  title: 'Memory leak in WebSocket connection handler',
  severity: 'high',
  events: 892,
  lastSeen: '1 hour ago',
  assignee: {
    name: 'Alex Kim',
    initials: 'AK'
  }
},
{
  id: 'ISS-1231',
  title: 'Slow database query on user dashboard',
  severity: 'medium',
  events: 456,
  lastSeen: '2 hours ago',
  assignee: {
    name: 'John Doe',
    initials: 'JD'
  }
},
{
  id: 'ISS-1230',
  title: 'CSS layout shift on mobile navigation',
  severity: 'low',
  events: 234,
  lastSeen: '4 hours ago',
  assignee: {
    name: 'Emma Wilson',
    initials: 'EW'
  }
}];

type MetricCardProps = {
  title: string;
  value: string;
  change: string;
  isPositive: boolean;
  icon: React.ReactNode;
  sparklineData: {
    value: number;
  }[];
  sparklineColor: string;
};
function MetricCard({
  title,
  value,
  change,
  isPositive,
  icon,
  sparklineData,
  sparklineColor
}: MetricCardProps) {
  return (
    <div className="sf-card p-5">
      <div className="flex items-start justify-between mb-4">
        <div>
          <p className="text-[#9b8fc2] text-sm font-medium mb-1">{title}</p>
          <p className="text-3xl font-bold text-[#e2dff0]">{value}</p>
        </div>
        <div className="w-10 h-10 rounded-lg bg-[#2d1f5e] flex items-center justify-center text-[#7c3aed]">
          {icon}
        </div>
      </div>
      <div className="flex items-center justify-between">
        <div
          className={`flex items-center gap-1 text-sm font-medium ${isPositive ? 'text-[#22c55e]' : 'text-[#e91e8c]'}`}>

          {isPositive ?
          <TrendingUpIcon className="w-4 h-4" /> :

          <TrendingDownIcon className="w-4 h-4" />
          }
          {change}
        </div>
        <div className="w-24 h-8">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={sparklineData}>
              <defs>
                <linearGradient
                  id={`gradient-${title}`}
                  x1="0"
                  y1="0"
                  x2="0"
                  y2="1">

                  <stop
                    offset="0%"
                    stopColor={sparklineColor}
                    stopOpacity={0.4} />

                  <stop
                    offset="100%"
                    stopColor={sparklineColor}
                    stopOpacity={0} />

                </linearGradient>
              </defs>
              <Area
                type="monotone"
                dataKey="value"
                stroke={sparklineColor}
                strokeWidth={2}
                fill={`url(#gradient-${title})`} />

            </AreaChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>);

}
function SeverityBadge({ severity }: {severity: string;}) {
  const styles: Record<string, string> = {
    critical: 'sf-badge-critical',
    high: 'sf-badge-high',
    medium: 'sf-badge-medium',
    low: 'sf-badge-low'
  };
  return (
    <span className={`sf-badge ${styles[severity] || 'sf-badge-info'}`}>
      {severity.charAt(0).toUpperCase() + severity.slice(1)}
    </span>);

}
export function DashboardPage() {
  const [showAlert, setShowAlert] = useState(true);
  return (
    <div className="min-h-screen">
      {/* Critical Alert Banner */}
      {showAlert &&
      <div className="bg-gradient-to-r from-[#e91e8c]/20 to-[#7c3aed]/20 border border-[#e91e8c]/40 rounded-xl p-4 mb-6 animate-pulse-glow">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg bg-[#e91e8c]/20 flex items-center justify-center">
                <AlertTriangleIcon className="w-5 h-5 text-[#e91e8c]" />
              </div>
              <div>
                <p className="font-semibold text-[#e2dff0]">
                  Critical: Conversion rate dropped 23% in the last 24 hours
                </p>
                <p className="text-sm text-[#9b8fc2]">
                  Investigate the checkout funnel for potential issues
                </p>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <Link to="/issues/ISS-1234" className="sf-btn-primary text-sm">
                View Details
              </Link>
              <button
              onClick={() => setShowAlert(false)}
              className="p-2 rounded-lg text-[#9b8fc2] hover:text-[#e2dff0] hover:bg-[#7c3aed]/10 transition-all">

                <XIcon className="w-5 h-5" />
              </button>
            </div>
          </div>
        </div>
      }

      {/* Header */}
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-3xl font-bold text-[#e2dff0] mb-1">Dashboard</h1>
          <p className="text-[#9b8fc2]">
            Monitor your application health and performance
          </p>
        </div>
        <button className="sf-btn-secondary flex items-center gap-2">
          <CalendarIcon className="w-4 h-4" />
          Last 24 hours
          <ChevronRightIcon className="w-4 h-4" />
        </button>
      </div>

      {/* Metric Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        <MetricCard
          title="Total Events"
          value="1.2M"
          change="+12.5%"
          isPositive={true}
          icon={<ActivityIcon className="w-5 h-5" />}
          sparklineData={eventsSparkline}
          sparklineColor="#7c3aed" />

        <MetricCard
          title="Error Rate"
          value="3.2%"
          change="-0.8%"
          isPositive={true}
          icon={<AlertTriangleIcon className="w-5 h-5" />}
          sparklineData={errorSparkline}
          sparklineColor="#22c55e" />

        <MetricCard
          title="P95 Latency"
          value="245ms"
          change="+18ms"
          isPositive={false}
          icon={<ClockIcon className="w-5 h-5" />}
          sparklineData={latencySparkline}
          sparklineColor="#e91e8c" />

        <MetricCard
          title="Active Users"
          value="48.2K"
          change="+5.3%"
          isPositive={true}
          icon={<UsersIcon className="w-5 h-5" />}
          sparklineData={usersSparkline}
          sparklineColor="#7c3aed" />

      </div>

      {/* Funnel and Issues Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Conversion Funnel */}
        <div className="sf-card p-6">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h2 className="text-xl font-semibold text-[#e2dff0]">
                Conversion Funnel
              </h2>
              <p className="text-sm text-[#9b8fc2]">
                User journey through checkout
              </p>
            </div>
            <button className="sf-btn-ghost text-sm">View Details</button>
          </div>
          <div className="space-y-4">
            {funnelData.map((step, index) =>
            <div key={step.name} className="relative">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm font-medium text-[#e2dff0]">
                    {step.name}
                  </span>
                  <div className="flex items-center gap-3">
                    <span className="text-sm text-[#9b8fc2]">
                      {step.value.toLocaleString()}
                    </span>
                    <span className="text-sm font-semibold text-[#7c3aed]">
                      {step.percent}%
                    </span>
                  </div>
                </div>
                <div className="h-8 bg-[#0f0a1e] rounded-lg overflow-hidden">
                  <div
                  className="h-full rounded-lg transition-all duration-500"
                  style={{
                    width: `${step.percent}%`,
                    background: `linear-gradient(90deg, #e91e8c ${100 - step.percent}%, #7c3aed 100%)`
                  }} />

                </div>
                {index < funnelData.length - 1 &&
              <div className="absolute -bottom-2 left-1/2 transform -translate-x-1/2 text-[#6b5f8a] text-xs">
                    ↓{' '}
                    {(funnelData[index + 1].value / step.value * 100).toFixed(
                  0
                )}
                    %
                  </div>
              }
              </div>
            )}
          </div>
        </div>

        {/* Recent Issues */}
        <div className="sf-card p-6">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h2 className="text-xl font-semibold text-[#e2dff0]">
                Recent Issues
              </h2>
              <p className="text-sm text-[#9b8fc2]">
                Latest errors and warnings
              </p>
            </div>
            <Link to="/issues" className="sf-btn-ghost text-sm">
              View All
            </Link>
          </div>
          <div className="space-y-3">
            {recentIssues.map((issue) =>
            <Link
              key={issue.id}
              to={`/issues/${issue.id}`}
              className="block p-3 rounded-lg bg-[#0f0a1e] hover:bg-[#2d1f5e]/30 border border-transparent hover:border-[rgba(124,58,237,0.3)] transition-all group">

                <div className="flex items-start justify-between gap-3">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1">
                      <span className="text-xs text-[#6b5f8a] font-mono">
                        {issue.id}
                      </span>
                      <SeverityBadge severity={issue.severity} />
                    </div>
                    <p className="text-sm text-[#e2dff0] truncate group-hover:text-[#7c3aed] transition-colors">
                      {issue.title}
                    </p>
                    <div className="flex items-center gap-4 mt-2 text-xs text-[#6b5f8a]">
                      <span>{issue.events.toLocaleString()} events</span>
                      <span>{issue.lastSeen}</span>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <div
                    className="w-7 h-7 rounded-full bg-gradient-to-br from-[#e91e8c] to-[#7c3aed] flex items-center justify-center text-white text-xs font-medium"
                    title={issue.assignee.name}>

                      {issue.assignee.initials}
                    </div>
                    <ChevronRightIcon className="w-4 h-4 text-[#6b5f8a] group-hover:text-[#7c3aed] transition-colors" />
                  </div>
                </div>
              </Link>
            )}
          </div>
        </div>
      </div>
    </div>);

}