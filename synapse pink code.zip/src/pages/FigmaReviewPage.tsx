import React, { useState } from 'react';
import {
  MessageSquareIcon,
  CheckCircleIcon,
  XCircleIcon,
  ChevronLeftIcon,
  ChevronRightIcon,
  ZoomInIcon,
  ZoomOutIcon,
  MaximizeIcon,
  DownloadIcon,
  ShareIcon,
  MoreHorizontalIcon,
  PlusIcon,
  EyeIcon,
  LayersIcon,
  PenToolIcon } from
'lucide-react';
// Mock design screens
const designScreens = [
{
  id: 1,
  name: 'Dashboard - Main View',
  status: 'approved',
  comments: 3,
  lastUpdated: '2 hours ago',
  thumbnail:
  'https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=400&h=300&fit=crop'
},
{
  id: 2,
  name: 'Issues List - Desktop',
  status: 'pending',
  comments: 5,
  lastUpdated: '4 hours ago',
  thumbnail:
  'https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=400&h=300&fit=crop'
},
{
  id: 3,
  name: 'Issue Detail - Expanded',
  status: 'changes_requested',
  comments: 8,
  lastUpdated: '1 day ago',
  thumbnail:
  'https://images.unsplash.com/photo-1504868584819-f8e8b4b6d7e3?w=400&h=300&fit=crop'
},
{
  id: 4,
  name: 'Settings - Profile Tab',
  status: 'approved',
  comments: 2,
  lastUpdated: '2 days ago',
  thumbnail:
  'https://images.unsplash.com/photo-1517694712202-14dd9538aa97?w=400&h=300&fit=crop'
},
{
  id: 5,
  name: 'Onboarding - Step 1',
  status: 'pending',
  comments: 0,
  lastUpdated: '3 days ago',
  thumbnail:
  'https://images.unsplash.com/photo-1559028012-481c04fa702d?w=400&h=300&fit=crop'
}];

// Mock comments
const mockComments = [
{
  id: 1,
  user: {
    name: 'Sarah Chen',
    initials: 'SC'
  },
  message:
  'The spacing between the metric cards looks a bit tight. Can we increase it to 24px?',
  timestamp: '2 hours ago',
  resolved: false,
  position: {
    x: 45,
    y: 30
  }
},
{
  id: 2,
  user: {
    name: 'Mike Ross',
    initials: 'MR'
  },
  message: 'Love the gradient on the alert banner! Very on-brand.',
  timestamp: '3 hours ago',
  resolved: true,
  position: {
    x: 20,
    y: 15
  }
},
{
  id: 3,
  user: {
    name: 'Alex Kim',
    initials: 'AK'
  },
  message: 'Should we add a hover state for the funnel bars?',
  timestamp: '4 hours ago',
  resolved: false,
  position: {
    x: 70,
    y: 60
  }
}];

function StatusBadge({ status }: {status: string;}) {
  const styles: Record<
    string,
    {
      bg: string;
      text: string;
      label: string;
    }> =
  {
    approved: {
      bg: 'bg-[#22c55e]/20',
      text: 'text-[#22c55e]',
      label: 'Approved'
    },
    pending: {
      bg: 'bg-[#f59e0b]/20',
      text: 'text-[#f59e0b]',
      label: 'Pending Review'
    },
    changes_requested: {
      bg: 'bg-[#e91e8c]/20',
      text: 'text-[#e91e8c]',
      label: 'Changes Requested'
    }
  };
  const style = styles[status] || styles.pending;
  return (
    <span
      className={`px-2 py-1 rounded-full text-xs font-medium ${style.bg} ${style.text}`}>

      {style.label}
    </span>);

}
export function FigmaReviewPage() {
  const [selectedScreen, setSelectedScreen] = useState(designScreens[0]);
  const [zoom, setZoom] = useState(100);
  const [showComments, setShowComments] = useState(true);
  return (
    <div className="min-h-screen">
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-3xl font-bold text-[#e2dff0] mb-1">
            Figma Review
          </h1>
          <p className="text-[#9b8fc2]">Review and approve design mockups</p>
        </div>
        <div className="flex items-center gap-3">
          <button className="sf-btn-secondary flex items-center gap-2">
            <ShareIcon className="w-4 h-4" />
            Share
          </button>
          <button className="sf-btn-primary flex items-center gap-2">
            <CheckCircleIcon className="w-4 h-4" />
            Approve All
          </button>
        </div>
      </div>

      <div className="grid grid-cols-4 gap-6">
        {/* Screen List */}
        <div className="col-span-1 space-y-4">
          <div className="sf-card p-4">
            <h2 className="text-sm font-semibold text-[#9b8fc2] uppercase tracking-wider mb-4">
              Screens
            </h2>
            <div className="space-y-3">
              {designScreens.map((screen) =>
              <button
                key={screen.id}
                onClick={() => setSelectedScreen(screen)}
                className={`w-full text-left p-3 rounded-lg transition-all ${selectedScreen.id === screen.id ? 'bg-[#7c3aed]/20 border border-[#7c3aed]/40' : 'bg-[#0f0a1e] hover:bg-[#2d1f5e]/30 border border-transparent'}`}>

                  <div className="aspect-video rounded-md overflow-hidden mb-2 bg-[#2d1f5e]">
                    <img
                    src={screen.thumbnail}
                    alt={screen.name}
                    className="w-full h-full object-cover" />

                  </div>
                  <p className="text-sm font-medium text-[#e2dff0] truncate">
                    {screen.name}
                  </p>
                  <div className="flex items-center justify-between mt-2">
                    <StatusBadge status={screen.status} />
                    <div className="flex items-center gap-1 text-[#6b5f8a]">
                      <MessageSquareIcon className="w-3 h-3" />
                      <span className="text-xs">{screen.comments}</span>
                    </div>
                  </div>
                </button>
              )}
            </div>
          </div>
        </div>

        {/* Main Preview */}
        <div className="col-span-2">
          <div className="sf-card overflow-hidden">
            {/* Toolbar */}
            <div className="p-3 border-b border-[rgba(124,58,237,0.2)] flex items-center justify-between">
              <div className="flex items-center gap-2">
                <button className="sf-btn-ghost p-2">
                  <ChevronLeftIcon className="w-4 h-4" />
                </button>
                <span className="text-sm text-[#9b8fc2]">
                  {designScreens.findIndex((s) => s.id === selectedScreen.id) +
                  1}{' '}
                  / {designScreens.length}
                </span>
                <button className="sf-btn-ghost p-2">
                  <ChevronRightIcon className="w-4 h-4" />
                </button>
              </div>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => setZoom(Math.max(50, zoom - 25))}
                  className="sf-btn-ghost p-2">

                  <ZoomOutIcon className="w-4 h-4" />
                </button>
                <span className="text-sm text-[#9b8fc2] w-12 text-center">
                  {zoom}%
                </span>
                <button
                  onClick={() => setZoom(Math.min(200, zoom + 25))}
                  className="sf-btn-ghost p-2">

                  <ZoomInIcon className="w-4 h-4" />
                </button>
                <div className="w-px h-6 bg-[rgba(124,58,237,0.2)] mx-2" />
                <button
                  onClick={() => setShowComments(!showComments)}
                  className={`sf-btn-ghost p-2 ${showComments ? 'text-[#7c3aed]' : ''}`}>

                  <MessageSquareIcon className="w-4 h-4" />
                </button>
                <button className="sf-btn-ghost p-2">
                  <LayersIcon className="w-4 h-4" />
                </button>
                <button className="sf-btn-ghost p-2">
                  <MaximizeIcon className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Preview Area */}
            <div className="relative bg-[#0f0a1e] p-8 min-h-[500px] flex items-center justify-center overflow-auto">
              <div
                className="relative transition-transform"
                style={{
                  transform: `scale(${zoom / 100})`
                }}>

                <img
                  src={selectedScreen.thumbnail}
                  alt={selectedScreen.name}
                  className="rounded-lg shadow-2xl max-w-full"
                  style={{
                    width: '800px',
                    height: '500px',
                    objectFit: 'cover'
                  }} />


                {/* Comment Markers */}
                {showComments &&
                mockComments.map((comment) =>
                <div
                  key={comment.id}
                  className="absolute w-6 h-6 rounded-full bg-[#e91e8c] flex items-center justify-center text-white text-xs font-bold cursor-pointer hover:scale-110 transition-transform"
                  style={{
                    left: `${comment.position.x}%`,
                    top: `${comment.position.y}%`
                  }}>

                      {comment.id}
                    </div>
                )}
              </div>

              {/* Add Comment Button */}
              <button className="absolute bottom-4 right-4 sf-btn-primary flex items-center gap-2">
                <PlusIcon className="w-4 h-4" />
                Add Comment
              </button>
            </div>
          </div>
        </div>

        {/* Comments Panel */}
        <div className="col-span-1">
          <div className="sf-card p-4">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-sm font-semibold text-[#9b8fc2] uppercase tracking-wider">
                Comments
              </h2>
              <span className="text-xs text-[#6b5f8a]">
                {mockComments.length} total
              </span>
            </div>

            <div className="space-y-4">
              {mockComments.map((comment) =>
              <div
                key={comment.id}
                className={`p-3 rounded-lg ${comment.resolved ? 'bg-[#0f0a1e] opacity-60' : 'bg-[#0f0a1e]'}`}>

                  <div className="flex items-start gap-3">
                    <div className="w-6 h-6 rounded-full bg-[#e91e8c] flex items-center justify-center text-white text-xs font-bold flex-shrink-0">
                      {comment.id}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-1">
                        <div className="w-5 h-5 rounded-full bg-gradient-to-br from-[#e91e8c] to-[#7c3aed] flex items-center justify-center text-white text-[8px] font-medium">
                          {comment.user.initials}
                        </div>
                        <span className="text-sm font-medium text-[#e2dff0]">
                          {comment.user.name}
                        </span>
                        <span className="text-xs text-[#6b5f8a]">
                          {comment.timestamp}
                        </span>
                      </div>
                      <p className="text-sm text-[#9b8fc2]">
                        {comment.message}
                      </p>
                      <div className="flex items-center gap-2 mt-2">
                        {comment.resolved ?
                      <span className="text-xs text-[#22c55e] flex items-center gap-1">
                            <CheckCircleIcon className="w-3 h-3" />
                            Resolved
                          </span> :

                      <>
                            <button className="text-xs text-[#7c3aed] hover:underline">
                              Reply
                            </button>
                            <button className="text-xs text-[#22c55e] hover:underline">
                              Resolve
                            </button>
                          </>
                      }
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* Screen Info */}
            <div className="mt-6 pt-4 border-t border-[rgba(124,58,237,0.2)]">
              <h3 className="text-sm font-semibold text-[#e2dff0] mb-3">
                {selectedScreen.name}
              </h3>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-[#6b5f8a]">Status</span>
                  <StatusBadge status={selectedScreen.status} />
                </div>
                <div className="flex justify-between">
                  <span className="text-[#6b5f8a]">Last Updated</span>
                  <span className="text-[#9b8fc2]">
                    {selectedScreen.lastUpdated}
                  </span>
                </div>
              </div>
              <div className="flex gap-2 mt-4">
                <button className="flex-1 sf-btn-secondary text-sm flex items-center justify-center gap-1">
                  <XCircleIcon className="w-4 h-4" />
                  Request Changes
                </button>
                <button className="flex-1 sf-btn-primary text-sm flex items-center justify-center gap-1">
                  <CheckCircleIcon className="w-4 h-4" />
                  Approve
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>);

}