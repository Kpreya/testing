import React from 'react';
import { Sidebar } from './Sidebar';
import { useLocation } from 'react-router-dom';
interface LayoutProps {
  children: React.ReactNode;
}
export function Layout({ children }: LayoutProps) {
  const location = useLocation();
  const isOnboarding = location.pathname === '/onboarding';
  if (isOnboarding) {
    return (
      <div className="min-h-screen bg-[#0f0a1e] text-[#e2dff0]">{children}</div>);

  }
  return (
    <div className="min-h-screen bg-[#0f0a1e] text-[#e2dff0] flex">
      <Sidebar />
      <main className="flex-1 ml-64 min-h-screen transition-all duration-300">
        <div className="p-8 max-w-7xl mx-auto">{children}</div>
      </main>
    </div>);

}