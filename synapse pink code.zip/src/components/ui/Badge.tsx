import React from 'react';
interface BadgeProps {
  children: React.ReactNode;
  variant?: 'default' | 'success' | 'warning' | 'danger' | 'neutral';
  className?: string;
}
export function Badge({
  children,
  variant = 'default',
  className = ''
}: BadgeProps) {
  const variants = {
    default: 'bg-[#7c3aed]/20 text-[#a78bfa] border-[#7c3aed]/30',
    success: 'bg-[#22c55e]/20 text-[#4ade80] border-[#22c55e]/30',
    warning: 'bg-[#f59e0b]/20 text-[#fbbf24] border-[#f59e0b]/30',
    danger: 'bg-[#e91e8c]/20 text-[#f472b6] border-[#e91e8c]/30',
    neutral: 'bg-gray-500/20 text-gray-400 border-gray-500/30'
  };
  return (
    <span
      className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium border ${variants[variant]} ${className}`}>

      {children}
    </span>);

}