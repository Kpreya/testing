import React from 'react';
interface CardProps extends React.HTMLAttributes<HTMLDivElement> {
  noPadding?: boolean;
}
export function Card({
  className = '',
  children,
  noPadding = false,
  ...props
}: CardProps) {
  return (
    <div
      className={`bg-[#1a1333] border border-[#7c3aed]/20 rounded-xl shadow-lg hover:shadow-[0_0_15px_rgba(124,58,237,0.15)] transition-all duration-300 ${className}`}
      {...props}>

      <div className={noPadding ? '' : 'p-6'}>{children}</div>
    </div>);

}