import React from 'react';
import { Loader2 } from 'lucide-react';
interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: 'primary' | 'secondary' | 'outline' | 'ghost' | 'danger';
  size?: 'sm' | 'md' | 'lg';
  isLoading?: boolean;
}
export function Button({
  children,
  variant = 'primary',
  size = 'md',
  isLoading = false,
  className = '',
  disabled,
  ...props
}: ButtonProps) {
  const baseStyles =
  'inline-flex items-center justify-center rounded-lg font-medium transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-[#0f0a1e] disabled:opacity-50 disabled:cursor-not-allowed';
  const variants = {
    primary:
    'bg-[#e91e8c] hover:bg-[#d81b81] text-white shadow-[0_0_10px_rgba(233,30,140,0.3)] hover:shadow-[0_0_15px_rgba(233,30,140,0.5)] border border-transparent',
    secondary:
    'bg-[#7c3aed] hover:bg-[#6d28d9] text-white shadow-[0_0_10px_rgba(124,58,237,0.3)] hover:shadow-[0_0_15px_rgba(124,58,237,0.5)] border border-transparent',
    outline:
    'bg-transparent border border-[#7c3aed]/50 text-[#e2dff0] hover:bg-[#7c3aed]/10 hover:border-[#7c3aed]',
    ghost:
    'bg-transparent text-[#9b8fc2] hover:text-[#e2dff0] hover:bg-[#7c3aed]/10',
    danger:
    'bg-red-500/10 text-red-400 border border-red-500/50 hover:bg-red-500/20'
  };
  const sizes = {
    sm: 'h-8 px-3 text-xs',
    md: 'h-10 px-4 py-2 text-sm',
    lg: 'h-12 px-6 text-base'
  };
  return (
    <button
      className={`${baseStyles} ${variants[variant]} ${sizes[size]} ${className}`}
      disabled={disabled || isLoading}
      {...props}>

      {isLoading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
      {children}
    </button>);

}