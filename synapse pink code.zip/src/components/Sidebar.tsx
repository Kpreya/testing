import React, { useState } from 'react';
import { NavLink, useLocation } from 'react-router-dom';
import {
  LayoutDashboardIcon,
  AlertCircleIcon,
  FileTextIcon,
  FigmaIcon,
  GitPullRequestIcon,
  SettingsIcon,
  ZapIcon,
  LogOutIcon,
  ChevronLeftIcon,
  ChevronRightIcon } from
'lucide-react';
type NavItem = {
  name: string;
  path: string;
  icon: React.ReactNode;
};
const navItems: NavItem[] = [
{
  name: 'Dashboard',
  path: '/',
  icon: <LayoutDashboardIcon className="w-5 h-5" />
},
{
  name: 'Issues',
  path: '/issues',
  icon: <AlertCircleIcon className="w-5 h-5" />
},
{
  name: 'Monthly Report',
  path: '/report',
  icon: <FileTextIcon className="w-5 h-5" />
},
{
  name: 'Figma Review',
  path: '/figma',
  icon: <FigmaIcon className="w-5 h-5" />
},
{
  name: 'GitHub PR',
  path: '/github',
  icon: <GitPullRequestIcon className="w-5 h-5" />
},
{
  name: 'Settings',
  path: '/settings',
  icon: <SettingsIcon className="w-5 h-5" />
}];

export function Sidebar() {
  const [collapsed, setCollapsed] = useState(false);
  const location = useLocation();
  return (
    <aside
      className={`fixed left-0 top-0 h-screen bg-[#150e2b] border-r border-[rgba(124,58,237,0.2)] flex flex-col transition-all duration-300 z-50 ${collapsed ? 'w-[72px]' : 'w-[240px]'}`}>

      {/* Logo */}
      <div className="p-4 flex items-center gap-3 border-b border-[rgba(124,58,237,0.2)]">
        <div className="w-10 h-10 rounded-xl sf-gradient-bg flex items-center justify-center sf-glow-magenta">
          <ZapIcon className="w-6 h-6 text-white" />
        </div>
        {!collapsed &&
        <span className="text-xl font-bold sf-gradient-text">
            SynapseFlow
          </span>
        }
      </div>

      {/* Navigation */}
      <nav className="flex-1 py-4 px-2 space-y-1 overflow-y-auto">
        {navItems.map((item) => {
          const isActive =
          item.path === '/' ?
          location.pathname === '/' :
          location.pathname.startsWith(item.path);
          return (
            <NavLink
              key={item.path}
              to={item.path}
              className={`flex items-center gap-3 px-3 py-2.5 rounded-lg transition-all group ${isActive ? 'bg-[#7c3aed]/20 text-[#e2dff0] border border-[#7c3aed]/40' : 'text-[#9b8fc2] hover:bg-[#7c3aed]/10 hover:text-[#e2dff0] border border-transparent'}`}>

              <span
                className={`flex-shrink-0 ${isActive ? 'text-[#7c3aed]' : 'group-hover:text-[#7c3aed]'}`}>

                {item.icon}
              </span>
              {!collapsed &&
              <span className="font-medium truncate">{item.name}</span>
              }
              {isActive && !collapsed &&
              <div className="ml-auto w-1.5 h-1.5 rounded-full bg-[#7c3aed]" />
              }
            </NavLink>);

        })}
      </nav>

      {/* Collapse toggle */}
      <button
        onClick={() => setCollapsed(!collapsed)}
        className="absolute -right-3 top-20 w-6 h-6 rounded-full bg-[#2d1f5e] border border-[rgba(124,58,237,0.3)] flex items-center justify-center text-[#9b8fc2] hover:text-[#e2dff0] hover:border-[#7c3aed] transition-all">

        {collapsed ?
        <ChevronRightIcon className="w-4 h-4" /> :

        <ChevronLeftIcon className="w-4 h-4" />
        }
      </button>

      {/* User section */}
      <div className="p-4 border-t border-[rgba(124,58,237,0.2)]">
        <div
          className={`flex items-center gap-3 ${collapsed ? 'justify-center' : ''}`}>

          <div className="w-9 h-9 rounded-full bg-gradient-to-br from-[#e91e8c] to-[#7c3aed] flex items-center justify-center text-white font-semibold text-sm">
            JD
          </div>
          {!collapsed &&
          <div className="flex-1 min-w-0">
              <p className="text-sm font-medium text-[#e2dff0] truncate">
                John Doe
              </p>
              <p className="text-xs text-[#6b5f8a] truncate">
                john@synapseflow.io
              </p>
            </div>
          }
          {!collapsed &&
          <button className="p-1.5 rounded-lg text-[#6b5f8a] hover:text-[#e2dff0] hover:bg-[#7c3aed]/10 transition-all">
              <LogOutIcon className="w-4 h-4" />
            </button>
          }
        </div>
      </div>
    </aside>);

}